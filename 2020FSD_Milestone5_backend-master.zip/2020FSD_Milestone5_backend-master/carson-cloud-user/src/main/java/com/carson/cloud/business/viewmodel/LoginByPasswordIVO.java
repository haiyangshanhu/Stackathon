package com.carson.cloud.business.viewmodel;

import lombok.Data;

@Data
public class LoginByPasswordIVO {
    private String userName;
    private String password;
}
