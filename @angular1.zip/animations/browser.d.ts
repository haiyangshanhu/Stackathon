/**
 * @license Angular v9.1.2
 * (c) 2010-2020 Google LLC. https://angular.io/
 * License: MIT
 */

export * from './browser/browser';
