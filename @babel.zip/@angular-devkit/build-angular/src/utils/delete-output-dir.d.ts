/**
 * Delete an output directory, but error out if it's the root of the project.
 */
export declare function deleteOutputDir(root: string, outputPath: string): void;
