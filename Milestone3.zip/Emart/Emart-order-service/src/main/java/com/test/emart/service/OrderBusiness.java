package com.test.emart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.test.emart.entity.OrderEntity;
import com.test.emart.repository.OrderRepository;

@Service
public class OrderBusiness implements OrderService{
	@Autowired
	private OrderRepository orderDao;

	@Override
	public void addOrder(OrderEntity item) {
		// TODO Auto-generated method stub
	}

	@Override
	public List<OrderEntity> getOrderByBuyerId(Integer id) {
		// TODO Auto-generated method stub
		return orderDao.getOrderByBuyerId(id);
	}

	@Override
	public List<OrderEntity> getOrderBySellerId(Integer id) {
		// TODO Auto-generated method stub
		return orderDao.getOrderBySellerId(id);
	}


}
