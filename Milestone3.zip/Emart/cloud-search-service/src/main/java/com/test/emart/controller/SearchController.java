package com.test.emart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.emart.entity.SearchEntity;
import com.test.emart.service.SearchService;

@RestController
@RequestMapping("/api/**")
@CrossOrigin(origins="http://localhost:4200")
public class SearchController {
	@Autowired
	private SearchService searchService;
	
	@GetMapping("/active/{productName}")
	public ResponseEntity<List<SearchEntity>> active(@PathVariable String productName){
		List<SearchEntity> productByName = searchService.findProductByName(productName);
		return ResponseEntity.ok(productByName); 
	}
	
	@GetMapping("/active/{productId}")
	public ResponseEntity<List<SearchEntity>> active(@PathVariable Integer productId){
		List<SearchEntity> productById  = searchService.findProductById(productId);
		return ResponseEntity.ok(productById); 
	}
	
	@PostMapping
	public ResponseEntity<SearchEntity> addItem(SearchEntity item){
		searchService.addItem(item);
		return ResponseEntity.status(HttpStatus.CREATED).body(item); 
	}

	@PutMapping
	public ResponseEntity<SearchEntity> updateQty(Integer addItem,Integer id){
		SearchEntity ProductEntity = searchService.updateQty(addItem,id);
		return ResponseEntity.ok(ProductEntity); 
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<String> deleteItem(@PathVariable Integer id){
		searchService.deleteItem(id);
		return ResponseEntity.ok("Delete Item successfully.");
	}
		
}
