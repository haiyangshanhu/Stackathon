package com.test.emart.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.test.emart.entity.SearchEntity;

@Repository
public interface SearchRepository extends JpaRepository<SearchEntity, Integer>{
	
	public SearchEntity findById(Integer productId);
	
	@Modifying
	@Transactional
	@Query(value = "select * from buyer where productId=?",nativeQuery = true)
	public List<SearchEntity> findProductById(Integer productId);
	
	@Modifying
	@Transactional
	@Query(value = "select * from buyer where productName=?",nativeQuery = true)
	public List<SearchEntity> findProductByName(String productName);
	
	@Modifying
	@Transactional
	@Query(value = "insert into s_order (id,buyer_id,seller_id,item_id,qty,transaction_type,crtDate)"
			+ "values(#{id},#{buyer_id},#{seller_id},#{item_id},#{qty},#{transaction_type},#{crtDate})",nativeQuery = true)
	public void addItem(SearchEntity item);
	
	@Modifying
	@Transactional
	@Query(value = "update s_product p set p.addItem=? where p.id=?",nativeQuery = true)
	public int updateQty(@Param("addItem")Integer qty,@Param("id")Integer id);
	
	@Transactional
	@Query(value = "select * from s_product p where p.id=?",nativeQuery = true)
	public SearchEntity getItemById(Integer id);
	
	@Transactional
	@Query(value = "delete from s_product p where p.id=?",nativeQuery = true)
	public void deleteItem(@Param("id")Integer id);
	
}

