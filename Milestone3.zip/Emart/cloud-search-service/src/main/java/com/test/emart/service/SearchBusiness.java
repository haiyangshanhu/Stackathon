package com.test.emart.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.test.emart.entity.SearchEntity;
import com.test.emart.repository.SearchRepository;

@Service
public class SearchBusiness implements SearchService{
	@Autowired
	private SearchRepository searchRepository;

	public Page<SearchEntity> findAll(int page, int pageSize) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public List<SearchEntity> findProductById(Integer productId) {
		return searchRepository.findProductById(productId);
	}
	@Override
	public List<SearchEntity> findProductByName(String productName) {
		return searchRepository.findProductByName(productName);
	}
	@Override
	public void addItem(SearchEntity item) {
		searchRepository.addItem(item);
		
	}
	@Override
	public SearchEntity updateQty(Integer addItem, Integer id) {
		searchRepository.updateQty(addItem,id);
		return searchRepository.getItemById(id);
	}
	@Override
	public void deleteItem(Integer id) {
		searchRepository.deleteItem(id);
		
	}
}
