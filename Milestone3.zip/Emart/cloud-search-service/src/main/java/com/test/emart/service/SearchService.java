package com.test.emart.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.test.emart.entity.SearchEntity;

public interface SearchService {

	/**
	 * get page information
	 * 
	 * @param page
	 * @param pageSize
	 * @return
	 */
	public Page<SearchEntity> findAll(int page, int pageSize);
	
	/**
	 * search All products by name
	 * 
	 * @return
	 */
	public List<SearchEntity> findProductByName(String productName);
	
	/**
	 * search All products by id
	 * 
	 * @param 
	 * @return
	 */
	public List<SearchEntity> findProductById(Integer productId);
	
	/**
	 * add products
	 * 
	 * @param item
	 * @return
	 */
	public void addItem(SearchEntity item);
	
	/**
	 * update products information by id
	 * 
	 * @param item
	 * @return
	 */
	public SearchEntity updateQty(Integer qty,Integer id);
	
	/**
	 * delete products by id
	 * 
	 * @param id
	 */
	public void deleteItem(Integer id);
	
}
