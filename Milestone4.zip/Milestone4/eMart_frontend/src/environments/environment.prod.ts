export const environment = {
  production: true,
  baseUrl: 'http://helloword'
};
