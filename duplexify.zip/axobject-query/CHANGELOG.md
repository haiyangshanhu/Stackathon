# axobject-query Change Log

## 1.0.1

- Changed label from structure to widget
- Added the CHANGELOG file

## 2.0.1

- Add NPM and Watchman configs
