import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sign-up-seller',
  templateUrl: './sign-up-seller.component.html',
  styleUrls: ['./sign-up-seller.component.css']
})
export class SignUpSellerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }


}
