import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './accordion';
import * as ɵngcc2 from '@angular/common';
export { NgbAccordion, NgbPanel, NgbPanelTitle, NgbPanelContent, NgbPanelChangeEvent, NgbPanelHeader, NgbPanelHeaderContext, NgbPanelToggle } from './accordion';
export { NgbAccordionConfig } from './accordion-config';
export declare class NgbAccordionModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbAccordionModule, [typeof ɵngcc1.NgbAccordion, typeof ɵngcc1.NgbPanel, typeof ɵngcc1.NgbPanelTitle, typeof ɵngcc1.NgbPanelContent, typeof ɵngcc1.NgbPanelHeader, typeof ɵngcc1.NgbPanelToggle], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbAccordion, typeof ɵngcc1.NgbPanel, typeof ɵngcc1.NgbPanelTitle, typeof ɵngcc1.NgbPanelContent, typeof ɵngcc1.NgbPanelHeader, typeof ɵngcc1.NgbPanelToggle]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbAccordionModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWNjb3JkaW9uLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJhY2NvcmRpb24ubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IE5nYkFjY29yZGlvbiwgTmdiUGFuZWwsIE5nYlBhbmVsVGl0bGUsIE5nYlBhbmVsQ29udGVudCwgTmdiUGFuZWxDaGFuZ2VFdmVudCwgTmdiUGFuZWxIZWFkZXIsIE5nYlBhbmVsSGVhZGVyQ29udGV4dCwgTmdiUGFuZWxUb2dnbGUgfSBmcm9tICcuL2FjY29yZGlvbic7XG5leHBvcnQgeyBOZ2JBY2NvcmRpb25Db25maWcgfSBmcm9tICcuL2FjY29yZGlvbi1jb25maWcnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQWNjb3JkaW9uTW9kdWxlIHtcbn1cbiJdfQ==