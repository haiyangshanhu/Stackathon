import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './alert';
import * as ɵngcc2 from '@angular/common';
export { NgbAlert } from './alert';
export { NgbAlertConfig } from './alert-config';
export declare class NgbAlertModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbAlertModule, [typeof ɵngcc1.NgbAlert], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbAlert]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbAlertModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWxlcnQubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbImFsZXJ0Lm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBOZ2JBbGVydCB9IGZyb20gJy4vYWxlcnQnO1xuZXhwb3J0IHsgTmdiQWxlcnRDb25maWcgfSBmcm9tICcuL2FsZXJ0LWNvbmZpZyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JBbGVydE1vZHVsZSB7XG59XG4iXX0=