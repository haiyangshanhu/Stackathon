import { ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgbButtonLabel } from './label';
/**
 * Allows to easily create Bootstrap-style checkbox buttons.
 *
 * Integrates with forms, so the value of a checked button is bound to the underlying form control
 * either in a reactive or template-driven way.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbCheckBox implements ControlValueAccessor {
    private _label;
    private _cd;
    static ngAcceptInputType_disabled: boolean | '';
    checked: any;
    /**
     * If `true`, the checkbox button will be disabled
     */
    disabled: boolean;
    /**
     * The form control value when the checkbox is checked.
     */
    valueChecked: boolean;
    /**
     * The form control value when the checkbox is unchecked.
     */
    valueUnChecked: boolean;
    onChange: (_: any) => void;
    onTouched: () => void;
    set focused(isFocused: boolean);
    constructor(_label: NgbButtonLabel, _cd: ChangeDetectorRef);
    onInputChange($event: any): void;
    registerOnChange(fn: (value: any) => any): void;
    registerOnTouched(fn: () => any): void;
    setDisabledState(isDisabled: boolean): void;
    writeValue(value: any): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbCheckBox, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbCheckBox, "[ngbButton][type=checkbox]", never, { "disabled": "disabled"; "valueChecked": "valueChecked"; "valueUnChecked": "valueUnChecked"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2hlY2tib3guZC50cyIsInNvdXJjZXMiOlsiY2hlY2tib3guZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29udHJvbFZhbHVlQWNjZXNzb3IgfSBmcm9tICdAYW5ndWxhci9mb3Jtcyc7XG5pbXBvcnQgeyBOZ2JCdXR0b25MYWJlbCB9IGZyb20gJy4vbGFiZWwnO1xuLyoqXG4gKiBBbGxvd3MgdG8gZWFzaWx5IGNyZWF0ZSBCb290c3RyYXAtc3R5bGUgY2hlY2tib3ggYnV0dG9ucy5cbiAqXG4gKiBJbnRlZ3JhdGVzIHdpdGggZm9ybXMsIHNvIHRoZSB2YWx1ZSBvZiBhIGNoZWNrZWQgYnV0dG9uIGlzIGJvdW5kIHRvIHRoZSB1bmRlcmx5aW5nIGZvcm0gY29udHJvbFxuICogZWl0aGVyIGluIGEgcmVhY3RpdmUgb3IgdGVtcGxhdGUtZHJpdmVuIHdheS5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQ2hlY2tCb3ggaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciB7XG4gICAgcHJpdmF0ZSBfbGFiZWw7XG4gICAgcHJpdmF0ZSBfY2Q7XG4gICAgc3RhdGljIG5nQWNjZXB0SW5wdXRUeXBlX2Rpc2FibGVkOiBib29sZWFuIHwgJyc7XG4gICAgY2hlY2tlZDogYW55O1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgdGhlIGNoZWNrYm94IGJ1dHRvbiB3aWxsIGJlIGRpc2FibGVkXG4gICAgICovXG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgLyoqXG4gICAgICogVGhlIGZvcm0gY29udHJvbCB2YWx1ZSB3aGVuIHRoZSBjaGVja2JveCBpcyBjaGVja2VkLlxuICAgICAqL1xuICAgIHZhbHVlQ2hlY2tlZDogYm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBUaGUgZm9ybSBjb250cm9sIHZhbHVlIHdoZW4gdGhlIGNoZWNrYm94IGlzIHVuY2hlY2tlZC5cbiAgICAgKi9cbiAgICB2YWx1ZVVuQ2hlY2tlZDogYm9vbGVhbjtcbiAgICBvbkNoYW5nZTogKF86IGFueSkgPT4gdm9pZDtcbiAgICBvblRvdWNoZWQ6ICgpID0+IHZvaWQ7XG4gICAgc2V0IGZvY3VzZWQoaXNGb2N1c2VkOiBib29sZWFuKTtcbiAgICBjb25zdHJ1Y3RvcihfbGFiZWw6IE5nYkJ1dHRvbkxhYmVsLCBfY2Q6IENoYW5nZURldGVjdG9yUmVmKTtcbiAgICBvbklucHV0Q2hhbmdlKCRldmVudDogYW55KTogdm9pZDtcbiAgICByZWdpc3Rlck9uQ2hhbmdlKGZuOiAodmFsdWU6IGFueSkgPT4gYW55KTogdm9pZDtcbiAgICByZWdpc3Rlck9uVG91Y2hlZChmbjogKCkgPT4gYW55KTogdm9pZDtcbiAgICBzZXREaXNhYmxlZFN0YXRlKGlzRGlzYWJsZWQ6IGJvb2xlYW4pOiB2b2lkO1xuICAgIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQ7XG59XG4iXX0=