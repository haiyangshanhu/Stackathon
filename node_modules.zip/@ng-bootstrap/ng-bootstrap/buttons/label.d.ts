import * as ɵngcc0 from '@angular/core';
export declare class NgbButtonLabel {
    active: boolean;
    disabled: boolean;
    focused: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbButtonLabel, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbButtonLabel, "[ngbButtonLabel]", never, {}, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibGFiZWwuZC50cyIsInNvdXJjZXMiOlsibGFiZWwuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQnV0dG9uTGFiZWwge1xuICAgIGFjdGl2ZTogYm9vbGVhbjtcbiAgICBkaXNhYmxlZDogYm9vbGVhbjtcbiAgICBmb2N1c2VkOiBib29sZWFuO1xufVxuIl19