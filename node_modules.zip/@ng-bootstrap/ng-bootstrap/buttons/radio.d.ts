import { ChangeDetectorRef, ElementRef, OnDestroy, Renderer2 } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgbButtonLabel } from './label';
/**
 * Allows to easily create Bootstrap-style radio buttons.
 *
 * Integrates with forms, so the value of a checked button is bound to the underlying form control
 * either in a reactive or template-driven way.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbRadioGroup implements ControlValueAccessor {
    private _radios;
    private _value;
    private _disabled;
    get disabled(): boolean;
    set disabled(isDisabled: boolean);
    /**
     * Name of the radio group applied to radio input elements.
     *
     * Will be applied to all radio input elements inside the group,
     * unless [`NgbRadio`](#/components/buttons/api#NgbRadio)'s specify names themselves.
     *
     * If not provided, will be generated in the `ngb-radio-xx` format.
     */
    name: string;
    onChange: (_: any) => void;
    onTouched: () => void;
    onRadioChange(radio: NgbRadio): void;
    onRadioValueUpdate(): void;
    register(radio: NgbRadio): void;
    registerOnChange(fn: (value: any) => any): void;
    registerOnTouched(fn: () => any): void;
    setDisabledState(isDisabled: boolean): void;
    unregister(radio: NgbRadio): void;
    writeValue(value: any): void;
    private _updateRadiosValue;
    private _updateRadiosDisabled;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbRadioGroup, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbRadioGroup, "[ngbRadioGroup]", never, { "name": "name"; }, {}, never>;
}
/**
 * A directive that marks an input of type "radio" as a part of the
 * [`NgbRadioGroup`](#/components/buttons/api#NgbRadioGroup).
 */
export declare class NgbRadio implements OnDestroy {
    private _group;
    private _label;
    private _renderer;
    private _element;
    private _cd;
    static ngAcceptInputType_disabled: boolean | '';
    private _checked;
    private _disabled;
    private _value;
    /**
     * The value for the 'name' property of the input element.
     *
     * All inputs of the radio group should have the same name. If not specified,
     * the name of the enclosing group is used.
     */
    name: string;
    /**
     * The form control value when current radio button is checked.
     */
    set value(value: any);
    /**
     * If `true`, current radio button will be disabled.
     */
    set disabled(isDisabled: boolean);
    set focused(isFocused: boolean);
    get checked(): boolean;
    get disabled(): boolean;
    get value(): any;
    get nameAttr(): string;
    constructor(_group: NgbRadioGroup, _label: NgbButtonLabel, _renderer: Renderer2, _element: ElementRef<HTMLInputElement>, _cd: ChangeDetectorRef);
    ngOnDestroy(): void;
    onChange(): void;
    updateValue(value: any): void;
    updateDisabled(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbRadio, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbRadio, "[ngbButton][type=radio]", never, { "value": "value"; "disabled": "disabled"; "name": "name"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmFkaW8uZC50cyIsInNvdXJjZXMiOlsicmFkaW8uZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDaGFuZ2VEZXRlY3RvclJlZiwgRWxlbWVudFJlZiwgT25EZXN0cm95LCBSZW5kZXJlcjIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgTmdiQnV0dG9uTGFiZWwgfSBmcm9tICcuL2xhYmVsJztcbi8qKlxuICogQWxsb3dzIHRvIGVhc2lseSBjcmVhdGUgQm9vdHN0cmFwLXN0eWxlIHJhZGlvIGJ1dHRvbnMuXG4gKlxuICogSW50ZWdyYXRlcyB3aXRoIGZvcm1zLCBzbyB0aGUgdmFsdWUgb2YgYSBjaGVja2VkIGJ1dHRvbiBpcyBib3VuZCB0byB0aGUgdW5kZXJseWluZyBmb3JtIGNvbnRyb2xcbiAqIGVpdGhlciBpbiBhIHJlYWN0aXZlIG9yIHRlbXBsYXRlLWRyaXZlbiB3YXkuXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlJhZGlvR3JvdXAgaW1wbGVtZW50cyBDb250cm9sVmFsdWVBY2Nlc3NvciB7XG4gICAgcHJpdmF0ZSBfcmFkaW9zO1xuICAgIHByaXZhdGUgX3ZhbHVlO1xuICAgIHByaXZhdGUgX2Rpc2FibGVkO1xuICAgIGdldCBkaXNhYmxlZCgpOiBib29sZWFuO1xuICAgIHNldCBkaXNhYmxlZChpc0Rpc2FibGVkOiBib29sZWFuKTtcbiAgICAvKipcbiAgICAgKiBOYW1lIG9mIHRoZSByYWRpbyBncm91cCBhcHBsaWVkIHRvIHJhZGlvIGlucHV0IGVsZW1lbnRzLlxuICAgICAqXG4gICAgICogV2lsbCBiZSBhcHBsaWVkIHRvIGFsbCByYWRpbyBpbnB1dCBlbGVtZW50cyBpbnNpZGUgdGhlIGdyb3VwLFxuICAgICAqIHVubGVzcyBbYE5nYlJhZGlvYF0oIy9jb21wb25lbnRzL2J1dHRvbnMvYXBpI05nYlJhZGlvKSdzIHNwZWNpZnkgbmFtZXMgdGhlbXNlbHZlcy5cbiAgICAgKlxuICAgICAqIElmIG5vdCBwcm92aWRlZCwgd2lsbCBiZSBnZW5lcmF0ZWQgaW4gdGhlIGBuZ2ItcmFkaW8teHhgIGZvcm1hdC5cbiAgICAgKi9cbiAgICBuYW1lOiBzdHJpbmc7XG4gICAgb25DaGFuZ2U6IChfOiBhbnkpID0+IHZvaWQ7XG4gICAgb25Ub3VjaGVkOiAoKSA9PiB2b2lkO1xuICAgIG9uUmFkaW9DaGFuZ2UocmFkaW86IE5nYlJhZGlvKTogdm9pZDtcbiAgICBvblJhZGlvVmFsdWVVcGRhdGUoKTogdm9pZDtcbiAgICByZWdpc3RlcihyYWRpbzogTmdiUmFkaW8pOiB2b2lkO1xuICAgIHJlZ2lzdGVyT25DaGFuZ2UoZm46ICh2YWx1ZTogYW55KSA9PiBhbnkpOiB2b2lkO1xuICAgIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoKSA9PiBhbnkpOiB2b2lkO1xuICAgIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQ7XG4gICAgdW5yZWdpc3RlcihyYWRpbzogTmdiUmFkaW8pOiB2b2lkO1xuICAgIHdyaXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQ7XG4gICAgcHJpdmF0ZSBfdXBkYXRlUmFkaW9zVmFsdWU7XG4gICAgcHJpdmF0ZSBfdXBkYXRlUmFkaW9zRGlzYWJsZWQ7XG59XG4vKipcbiAqIEEgZGlyZWN0aXZlIHRoYXQgbWFya3MgYW4gaW5wdXQgb2YgdHlwZSBcInJhZGlvXCIgYXMgYSBwYXJ0IG9mIHRoZVxuICogW2BOZ2JSYWRpb0dyb3VwYF0oIy9jb21wb25lbnRzL2J1dHRvbnMvYXBpI05nYlJhZGlvR3JvdXApLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JSYWRpbyBpbXBsZW1lbnRzIE9uRGVzdHJveSB7XG4gICAgcHJpdmF0ZSBfZ3JvdXA7XG4gICAgcHJpdmF0ZSBfbGFiZWw7XG4gICAgcHJpdmF0ZSBfcmVuZGVyZXI7XG4gICAgcHJpdmF0ZSBfZWxlbWVudDtcbiAgICBwcml2YXRlIF9jZDtcbiAgICBzdGF0aWMgbmdBY2NlcHRJbnB1dFR5cGVfZGlzYWJsZWQ6IGJvb2xlYW4gfCAnJztcbiAgICBwcml2YXRlIF9jaGVja2VkO1xuICAgIHByaXZhdGUgX2Rpc2FibGVkO1xuICAgIHByaXZhdGUgX3ZhbHVlO1xuICAgIC8qKlxuICAgICAqIFRoZSB2YWx1ZSBmb3IgdGhlICduYW1lJyBwcm9wZXJ0eSBvZiB0aGUgaW5wdXQgZWxlbWVudC5cbiAgICAgKlxuICAgICAqIEFsbCBpbnB1dHMgb2YgdGhlIHJhZGlvIGdyb3VwIHNob3VsZCBoYXZlIHRoZSBzYW1lIG5hbWUuIElmIG5vdCBzcGVjaWZpZWQsXG4gICAgICogdGhlIG5hbWUgb2YgdGhlIGVuY2xvc2luZyBncm91cCBpcyB1c2VkLlxuICAgICAqL1xuICAgIG5hbWU6IHN0cmluZztcbiAgICAvKipcbiAgICAgKiBUaGUgZm9ybSBjb250cm9sIHZhbHVlIHdoZW4gY3VycmVudCByYWRpbyBidXR0b24gaXMgY2hlY2tlZC5cbiAgICAgKi9cbiAgICBzZXQgdmFsdWUodmFsdWU6IGFueSk7XG4gICAgLyoqXG4gICAgICogSWYgYHRydWVgLCBjdXJyZW50IHJhZGlvIGJ1dHRvbiB3aWxsIGJlIGRpc2FibGVkLlxuICAgICAqL1xuICAgIHNldCBkaXNhYmxlZChpc0Rpc2FibGVkOiBib29sZWFuKTtcbiAgICBzZXQgZm9jdXNlZChpc0ZvY3VzZWQ6IGJvb2xlYW4pO1xuICAgIGdldCBjaGVja2VkKCk6IGJvb2xlYW47XG4gICAgZ2V0IGRpc2FibGVkKCk6IGJvb2xlYW47XG4gICAgZ2V0IHZhbHVlKCk6IGFueTtcbiAgICBnZXQgbmFtZUF0dHIoKTogc3RyaW5nO1xuICAgIGNvbnN0cnVjdG9yKF9ncm91cDogTmdiUmFkaW9Hcm91cCwgX2xhYmVsOiBOZ2JCdXR0b25MYWJlbCwgX3JlbmRlcmVyOiBSZW5kZXJlcjIsIF9lbGVtZW50OiBFbGVtZW50UmVmPEhUTUxJbnB1dEVsZW1lbnQ+LCBfY2Q6IENoYW5nZURldGVjdG9yUmVmKTtcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkO1xuICAgIG9uQ2hhbmdlKCk6IHZvaWQ7XG4gICAgdXBkYXRlVmFsdWUodmFsdWU6IGFueSk6IHZvaWQ7XG4gICAgdXBkYXRlRGlzYWJsZWQoKTogdm9pZDtcbn1cbiJdfQ==