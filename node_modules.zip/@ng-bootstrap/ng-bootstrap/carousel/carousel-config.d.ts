/**
 * A configuration service for the [NgbCarousel](#/components/carousel/api#NgbCarousel) component.
 *
 * You can inject this service, typically in your root component, and customize its properties
 * to provide default values for all carousels used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbCarouselConfig {
    interval: number;
    wrap: boolean;
    keyboard: boolean;
    pauseOnHover: boolean;
    showNavigationArrows: boolean;
    showNavigationIndicators: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbCarouselConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2Fyb3VzZWwtY29uZmlnLmQudHMiLCJzb3VyY2VzIjpbImNhcm91c2VsLWNvbmZpZy5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQSBjb25maWd1cmF0aW9uIHNlcnZpY2UgZm9yIHRoZSBbTmdiQ2Fyb3VzZWxdKCMvY29tcG9uZW50cy9jYXJvdXNlbC9hcGkjTmdiQ2Fyb3VzZWwpIGNvbXBvbmVudC5cbiAqXG4gKiBZb3UgY2FuIGluamVjdCB0aGlzIHNlcnZpY2UsIHR5cGljYWxseSBpbiB5b3VyIHJvb3QgY29tcG9uZW50LCBhbmQgY3VzdG9taXplIGl0cyBwcm9wZXJ0aWVzXG4gKiB0byBwcm92aWRlIGRlZmF1bHQgdmFsdWVzIGZvciBhbGwgY2Fyb3VzZWxzIHVzZWQgaW4gdGhlIGFwcGxpY2F0aW9uLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JDYXJvdXNlbENvbmZpZyB7XG4gICAgaW50ZXJ2YWw6IG51bWJlcjtcbiAgICB3cmFwOiBib29sZWFuO1xuICAgIGtleWJvYXJkOiBib29sZWFuO1xuICAgIHBhdXNlT25Ib3ZlcjogYm9vbGVhbjtcbiAgICBzaG93TmF2aWdhdGlvbkFycm93czogYm9vbGVhbjtcbiAgICBzaG93TmF2aWdhdGlvbkluZGljYXRvcnM6IGJvb2xlYW47XG59XG4iXX0=