import { AfterContentChecked, AfterContentInit, ChangeDetectorRef, EventEmitter, NgZone, OnDestroy, QueryList, TemplateRef } from '@angular/core';
import { NgbCarouselConfig } from './carousel-config';
/**
 * A directive that wraps the individual carousel slide.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbSlide {
    tplRef: TemplateRef<any>;
    /**
     * Slide id that must be unique for the entire document.
     *
     * If not provided, will be generated in the `ngb-slide-xx` format.
     */
    id: string;
    constructor(tplRef: TemplateRef<any>);
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbSlide, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbSlide, "ng-template[ngbSlide]", never, { "id": "id"; }, {}, never>;
}
/**
 * Carousel is a component to easily create and control slideshows.
 *
 * Allows to set intervals, change the way user interacts with the slides and provides a programmatic API.
 */
export declare class NgbCarousel implements AfterContentChecked, AfterContentInit, OnDestroy {
    private _platformId;
    private _ngZone;
    private _cd;
    slides: QueryList<NgbSlide>;
    NgbSlideEventSource: typeof NgbSlideEventSource;
    private _destroy$;
    private _interval$;
    private _mouseHover$;
    private _pauseOnHover$;
    private _pause$;
    private _wrap$;
    /**
     * The slide id that should be displayed **initially**.
     *
     * For subsequent interactions use methods `select()`, `next()`, etc. and the `(slide)` output.
     */
    activeId: string;
    /**
     * Time in milliseconds before the next slide is shown.
     */
    set interval(value: number);
    get interval(): number;
    /**
     * If `true`, will 'wrap' the carousel by switching from the last slide back to the first.
     */
    set wrap(value: boolean);
    get wrap(): boolean;
    /**
     * If `true`, allows to interact with carousel using keyboard 'arrow left' and 'arrow right'.
     */
    keyboard: boolean;
    /**
     * If `true`, will pause slide switching when mouse cursor hovers the slide.
     *
     * @since 2.2.0
     */
    set pauseOnHover(value: boolean);
    get pauseOnHover(): boolean;
    /**
     * If `true`, 'previous' and 'next' navigation arrows will be visible on the slide.
     *
     * @since 2.2.0
     */
    showNavigationArrows: boolean;
    /**
     * If `true`, navigation indicators at the bottom of the slide will be visible.
     *
     * @since 2.2.0
     */
    showNavigationIndicators: boolean;
    /**
     * An event emitted right after the slide transition is completed.
     *
     * See [`NgbSlideEvent`](#/components/carousel/api#NgbSlideEvent) for payload details.
     */
    slide: EventEmitter<NgbSlideEvent>;
    constructor(config: NgbCarouselConfig, _platformId: any, _ngZone: NgZone, _cd: ChangeDetectorRef);
    mouseEnter(): void;
    mouseLeave(): void;
    ngAfterContentInit(): void;
    ngAfterContentChecked(): void;
    ngOnDestroy(): void;
    /**
     * Navigates to a slide with the specified identifier.
     */
    select(slideId: string, source?: NgbSlideEventSource): void;
    /**
     * Navigates to the previous slide.
     */
    prev(source?: NgbSlideEventSource): void;
    /**
     * Navigates to the next slide.
     */
    next(source?: NgbSlideEventSource): void;
    /**
     * Pauses cycling through the slides.
     */
    pause(): void;
    /**
     * Restarts cycling through the slides from left to right.
     */
    cycle(): void;
    private _cycleToSelected;
    private _getSlideEventDirection;
    private _getSlideById;
    private _getSlideIdxById;
    private _getNextSlide;
    private _getPrevSlide;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbCarousel, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbCarousel, "ngb-carousel", ["ngbCarousel"], { "interval": "interval"; "wrap": "wrap"; "keyboard": "keyboard"; "pauseOnHover": "pauseOnHover"; "showNavigationArrows": "showNavigationArrows"; "showNavigationIndicators": "showNavigationIndicators"; "activeId": "activeId"; }, { "slide": "slide"; }, ["slides"], never>;
}
/**
 * A slide change event emitted right after the slide transition is completed.
 */
export interface NgbSlideEvent {
    /**
     * The previous slide id.
     */
    prev: string;
    /**
     * The current slide id.
     */
    current: string;
    /**
     * The slide event direction.
     *
     * Possible values are `'left' | 'right'`.
     */
    direction: NgbSlideEventDirection;
    /**
     * Whether the pause() method was called (and no cycle() call was done afterwards).
     *
     * @since 5.1.0
     */
    paused: boolean;
    /**
     * Source triggering the slide change event.
     *
     * Possible values are `'timer' | 'arrowLeft' | 'arrowRight' | 'indicator'`
     *
     * @since 5.1.0
     */
    source?: NgbSlideEventSource;
}
/**
 * Defines the carousel slide transition direction.
 */
export declare enum NgbSlideEventDirection {
    LEFT,
    RIGHT
}
export declare enum NgbSlideEventSource {
    TIMER = "timer",
    ARROW_LEFT = "arrowLeft",
    ARROW_RIGHT = "arrowRight",
    INDICATOR = "indicator"
}
export declare const NGB_CAROUSEL_DIRECTIVES: (typeof NgbSlide | typeof NgbCarousel)[];

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2Fyb3VzZWwuZC50cyIsInNvdXJjZXMiOlsiY2Fyb3VzZWwuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWZ0ZXJDb250ZW50Q2hlY2tlZCwgQWZ0ZXJDb250ZW50SW5pdCwgQ2hhbmdlRGV0ZWN0b3JSZWYsIEV2ZW50RW1pdHRlciwgTmdab25lLCBPbkRlc3Ryb3ksIFF1ZXJ5TGlzdCwgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nYkNhcm91c2VsQ29uZmlnIH0gZnJvbSAnLi9jYXJvdXNlbC1jb25maWcnO1xuLyoqXG4gKiBBIGRpcmVjdGl2ZSB0aGF0IHdyYXBzIHRoZSBpbmRpdmlkdWFsIGNhcm91c2VsIHNsaWRlLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JTbGlkZSB7XG4gICAgdHBsUmVmOiBUZW1wbGF0ZVJlZjxhbnk+O1xuICAgIC8qKlxuICAgICAqIFNsaWRlIGlkIHRoYXQgbXVzdCBiZSB1bmlxdWUgZm9yIHRoZSBlbnRpcmUgZG9jdW1lbnQuXG4gICAgICpcbiAgICAgKiBJZiBub3QgcHJvdmlkZWQsIHdpbGwgYmUgZ2VuZXJhdGVkIGluIHRoZSBgbmdiLXNsaWRlLXh4YCBmb3JtYXQuXG4gICAgICovXG4gICAgaWQ6IHN0cmluZztcbiAgICBjb25zdHJ1Y3Rvcih0cGxSZWY6IFRlbXBsYXRlUmVmPGFueT4pO1xufVxuLyoqXG4gKiBDYXJvdXNlbCBpcyBhIGNvbXBvbmVudCB0byBlYXNpbHkgY3JlYXRlIGFuZCBjb250cm9sIHNsaWRlc2hvd3MuXG4gKlxuICogQWxsb3dzIHRvIHNldCBpbnRlcnZhbHMsIGNoYW5nZSB0aGUgd2F5IHVzZXIgaW50ZXJhY3RzIHdpdGggdGhlIHNsaWRlcyBhbmQgcHJvdmlkZXMgYSBwcm9ncmFtbWF0aWMgQVBJLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JDYXJvdXNlbCBpbXBsZW1lbnRzIEFmdGVyQ29udGVudENoZWNrZWQsIEFmdGVyQ29udGVudEluaXQsIE9uRGVzdHJveSB7XG4gICAgcHJpdmF0ZSBfcGxhdGZvcm1JZDtcbiAgICBwcml2YXRlIF9uZ1pvbmU7XG4gICAgcHJpdmF0ZSBfY2Q7XG4gICAgc2xpZGVzOiBRdWVyeUxpc3Q8TmdiU2xpZGU+O1xuICAgIE5nYlNsaWRlRXZlbnRTb3VyY2U6IHR5cGVvZiBOZ2JTbGlkZUV2ZW50U291cmNlO1xuICAgIHByaXZhdGUgX2Rlc3Ryb3kkO1xuICAgIHByaXZhdGUgX2ludGVydmFsJDtcbiAgICBwcml2YXRlIF9tb3VzZUhvdmVyJDtcbiAgICBwcml2YXRlIF9wYXVzZU9uSG92ZXIkO1xuICAgIHByaXZhdGUgX3BhdXNlJDtcbiAgICBwcml2YXRlIF93cmFwJDtcbiAgICAvKipcbiAgICAgKiBUaGUgc2xpZGUgaWQgdGhhdCBzaG91bGQgYmUgZGlzcGxheWVkICoqaW5pdGlhbGx5KiouXG4gICAgICpcbiAgICAgKiBGb3Igc3Vic2VxdWVudCBpbnRlcmFjdGlvbnMgdXNlIG1ldGhvZHMgYHNlbGVjdCgpYCwgYG5leHQoKWAsIGV0Yy4gYW5kIHRoZSBgKHNsaWRlKWAgb3V0cHV0LlxuICAgICAqL1xuICAgIGFjdGl2ZUlkOiBzdHJpbmc7XG4gICAgLyoqXG4gICAgICogVGltZSBpbiBtaWxsaXNlY29uZHMgYmVmb3JlIHRoZSBuZXh0IHNsaWRlIGlzIHNob3duLlxuICAgICAqL1xuICAgIHNldCBpbnRlcnZhbCh2YWx1ZTogbnVtYmVyKTtcbiAgICBnZXQgaW50ZXJ2YWwoKTogbnVtYmVyO1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgd2lsbCAnd3JhcCcgdGhlIGNhcm91c2VsIGJ5IHN3aXRjaGluZyBmcm9tIHRoZSBsYXN0IHNsaWRlIGJhY2sgdG8gdGhlIGZpcnN0LlxuICAgICAqL1xuICAgIHNldCB3cmFwKHZhbHVlOiBib29sZWFuKTtcbiAgICBnZXQgd3JhcCgpOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgYWxsb3dzIHRvIGludGVyYWN0IHdpdGggY2Fyb3VzZWwgdXNpbmcga2V5Ym9hcmQgJ2Fycm93IGxlZnQnIGFuZCAnYXJyb3cgcmlnaHQnLlxuICAgICAqL1xuICAgIGtleWJvYXJkOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgd2lsbCBwYXVzZSBzbGlkZSBzd2l0Y2hpbmcgd2hlbiBtb3VzZSBjdXJzb3IgaG92ZXJzIHRoZSBzbGlkZS5cbiAgICAgKlxuICAgICAqIEBzaW5jZSAyLjIuMFxuICAgICAqL1xuICAgIHNldCBwYXVzZU9uSG92ZXIodmFsdWU6IGJvb2xlYW4pO1xuICAgIGdldCBwYXVzZU9uSG92ZXIoKTogYm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBJZiBgdHJ1ZWAsICdwcmV2aW91cycgYW5kICduZXh0JyBuYXZpZ2F0aW9uIGFycm93cyB3aWxsIGJlIHZpc2libGUgb24gdGhlIHNsaWRlLlxuICAgICAqXG4gICAgICogQHNpbmNlIDIuMi4wXG4gICAgICovXG4gICAgc2hvd05hdmlnYXRpb25BcnJvd3M6IGJvb2xlYW47XG4gICAgLyoqXG4gICAgICogSWYgYHRydWVgLCBuYXZpZ2F0aW9uIGluZGljYXRvcnMgYXQgdGhlIGJvdHRvbSBvZiB0aGUgc2xpZGUgd2lsbCBiZSB2aXNpYmxlLlxuICAgICAqXG4gICAgICogQHNpbmNlIDIuMi4wXG4gICAgICovXG4gICAgc2hvd05hdmlnYXRpb25JbmRpY2F0b3JzOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIEFuIGV2ZW50IGVtaXR0ZWQgcmlnaHQgYWZ0ZXIgdGhlIHNsaWRlIHRyYW5zaXRpb24gaXMgY29tcGxldGVkLlxuICAgICAqXG4gICAgICogU2VlIFtgTmdiU2xpZGVFdmVudGBdKCMvY29tcG9uZW50cy9jYXJvdXNlbC9hcGkjTmdiU2xpZGVFdmVudCkgZm9yIHBheWxvYWQgZGV0YWlscy5cbiAgICAgKi9cbiAgICBzbGlkZTogRXZlbnRFbWl0dGVyPE5nYlNsaWRlRXZlbnQ+O1xuICAgIGNvbnN0cnVjdG9yKGNvbmZpZzogTmdiQ2Fyb3VzZWxDb25maWcsIF9wbGF0Zm9ybUlkOiBhbnksIF9uZ1pvbmU6IE5nWm9uZSwgX2NkOiBDaGFuZ2VEZXRlY3RvclJlZik7XG4gICAgbW91c2VFbnRlcigpOiB2b2lkO1xuICAgIG1vdXNlTGVhdmUoKTogdm9pZDtcbiAgICBuZ0FmdGVyQ29udGVudEluaXQoKTogdm9pZDtcbiAgICBuZ0FmdGVyQ29udGVudENoZWNrZWQoKTogdm9pZDtcbiAgICBuZ09uRGVzdHJveSgpOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIE5hdmlnYXRlcyB0byBhIHNsaWRlIHdpdGggdGhlIHNwZWNpZmllZCBpZGVudGlmaWVyLlxuICAgICAqL1xuICAgIHNlbGVjdChzbGlkZUlkOiBzdHJpbmcsIHNvdXJjZT86IE5nYlNsaWRlRXZlbnRTb3VyY2UpOiB2b2lkO1xuICAgIC8qKlxuICAgICAqIE5hdmlnYXRlcyB0byB0aGUgcHJldmlvdXMgc2xpZGUuXG4gICAgICovXG4gICAgcHJldihzb3VyY2U/OiBOZ2JTbGlkZUV2ZW50U291cmNlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBOYXZpZ2F0ZXMgdG8gdGhlIG5leHQgc2xpZGUuXG4gICAgICovXG4gICAgbmV4dChzb3VyY2U/OiBOZ2JTbGlkZUV2ZW50U291cmNlKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBQYXVzZXMgY3ljbGluZyB0aHJvdWdoIHRoZSBzbGlkZXMuXG4gICAgICovXG4gICAgcGF1c2UoKTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBSZXN0YXJ0cyBjeWNsaW5nIHRocm91Z2ggdGhlIHNsaWRlcyBmcm9tIGxlZnQgdG8gcmlnaHQuXG4gICAgICovXG4gICAgY3ljbGUoKTogdm9pZDtcbiAgICBwcml2YXRlIF9jeWNsZVRvU2VsZWN0ZWQ7XG4gICAgcHJpdmF0ZSBfZ2V0U2xpZGVFdmVudERpcmVjdGlvbjtcbiAgICBwcml2YXRlIF9nZXRTbGlkZUJ5SWQ7XG4gICAgcHJpdmF0ZSBfZ2V0U2xpZGVJZHhCeUlkO1xuICAgIHByaXZhdGUgX2dldE5leHRTbGlkZTtcbiAgICBwcml2YXRlIF9nZXRQcmV2U2xpZGU7XG59XG4vKipcbiAqIEEgc2xpZGUgY2hhbmdlIGV2ZW50IGVtaXR0ZWQgcmlnaHQgYWZ0ZXIgdGhlIHNsaWRlIHRyYW5zaXRpb24gaXMgY29tcGxldGVkLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIE5nYlNsaWRlRXZlbnQge1xuICAgIC8qKlxuICAgICAqIFRoZSBwcmV2aW91cyBzbGlkZSBpZC5cbiAgICAgKi9cbiAgICBwcmV2OiBzdHJpbmc7XG4gICAgLyoqXG4gICAgICogVGhlIGN1cnJlbnQgc2xpZGUgaWQuXG4gICAgICovXG4gICAgY3VycmVudDogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIFRoZSBzbGlkZSBldmVudCBkaXJlY3Rpb24uXG4gICAgICpcbiAgICAgKiBQb3NzaWJsZSB2YWx1ZXMgYXJlIGAnbGVmdCcgfCAncmlnaHQnYC5cbiAgICAgKi9cbiAgICBkaXJlY3Rpb246IE5nYlNsaWRlRXZlbnREaXJlY3Rpb247XG4gICAgLyoqXG4gICAgICogV2hldGhlciB0aGUgcGF1c2UoKSBtZXRob2Qgd2FzIGNhbGxlZCAoYW5kIG5vIGN5Y2xlKCkgY2FsbCB3YXMgZG9uZSBhZnRlcndhcmRzKS5cbiAgICAgKlxuICAgICAqIEBzaW5jZSA1LjEuMFxuICAgICAqL1xuICAgIHBhdXNlZDogYm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBTb3VyY2UgdHJpZ2dlcmluZyB0aGUgc2xpZGUgY2hhbmdlIGV2ZW50LlxuICAgICAqXG4gICAgICogUG9zc2libGUgdmFsdWVzIGFyZSBgJ3RpbWVyJyB8ICdhcnJvd0xlZnQnIHwgJ2Fycm93UmlnaHQnIHwgJ2luZGljYXRvcidgXG4gICAgICpcbiAgICAgKiBAc2luY2UgNS4xLjBcbiAgICAgKi9cbiAgICBzb3VyY2U/OiBOZ2JTbGlkZUV2ZW50U291cmNlO1xufVxuLyoqXG4gKiBEZWZpbmVzIHRoZSBjYXJvdXNlbCBzbGlkZSB0cmFuc2l0aW9uIGRpcmVjdGlvbi5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgZW51bSBOZ2JTbGlkZUV2ZW50RGlyZWN0aW9uIHtcbiAgICBMRUZULFxuICAgIFJJR0hUXG59XG5leHBvcnQgZGVjbGFyZSBlbnVtIE5nYlNsaWRlRXZlbnRTb3VyY2Uge1xuICAgIFRJTUVSID0gXCJ0aW1lclwiLFxuICAgIEFSUk9XX0xFRlQgPSBcImFycm93TGVmdFwiLFxuICAgIEFSUk9XX1JJR0hUID0gXCJhcnJvd1JpZ2h0XCIsXG4gICAgSU5ESUNBVE9SID0gXCJpbmRpY2F0b3JcIlxufVxuZXhwb3J0IGRlY2xhcmUgY29uc3QgTkdCX0NBUk9VU0VMX0RJUkVDVElWRVM6ICh0eXBlb2YgTmdiU2xpZGUgfCB0eXBlb2YgTmdiQ2Fyb3VzZWwpW107XG4iXX0=