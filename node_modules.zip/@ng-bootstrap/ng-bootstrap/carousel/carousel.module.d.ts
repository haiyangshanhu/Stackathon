import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './carousel';
import * as ɵngcc2 from '@angular/common';
export { NgbCarousel, NgbSlide, NgbSlideEvent, NgbSlideEventDirection, NgbSlideEventSource } from './carousel';
export { NgbCarouselConfig } from './carousel-config';
export declare class NgbCarouselModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbCarouselModule, [typeof ɵngcc1.NgbCarousel, typeof ɵngcc1.NgbSlide], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbCarousel, typeof ɵngcc1.NgbSlide]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbCarouselModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2Fyb3VzZWwubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbImNhcm91c2VsLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBOZ2JDYXJvdXNlbCwgTmdiU2xpZGUsIE5nYlNsaWRlRXZlbnQsIE5nYlNsaWRlRXZlbnREaXJlY3Rpb24sIE5nYlNsaWRlRXZlbnRTb3VyY2UgfSBmcm9tICcuL2Nhcm91c2VsJztcbmV4cG9ydCB7IE5nYkNhcm91c2VsQ29uZmlnIH0gZnJvbSAnLi9jYXJvdXNlbC1jb25maWcnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQ2Fyb3VzZWxNb2R1bGUge1xufVxuIl19