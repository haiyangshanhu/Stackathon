/**
 * A directive to provide a simple way of hiding and showing elements on the page.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbCollapse {
    /**
     * If `true`, will collapse the element or show it otherwise.
     */
    collapsed: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbCollapse, never>;
    static ɵdir: ɵngcc0.ɵɵDirectiveDefWithMeta<NgbCollapse, "[ngbCollapse]", ["ngbCollapse"], { "collapsed": "ngbCollapse"; }, {}, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sbGFwc2UuZC50cyIsInNvdXJjZXMiOlsiY29sbGFwc2UuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEEgZGlyZWN0aXZlIHRvIHByb3ZpZGUgYSBzaW1wbGUgd2F5IG9mIGhpZGluZyBhbmQgc2hvd2luZyBlbGVtZW50cyBvbiB0aGUgcGFnZS5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQ29sbGFwc2Uge1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgd2lsbCBjb2xsYXBzZSB0aGUgZWxlbWVudCBvciBzaG93IGl0IG90aGVyd2lzZS5cbiAgICAgKi9cbiAgICBjb2xsYXBzZWQ6IGJvb2xlYW47XG59XG4iXX0=