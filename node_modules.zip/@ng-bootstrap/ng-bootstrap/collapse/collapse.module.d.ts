import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './collapse';
export { NgbCollapse } from './collapse';
export declare class NgbCollapseModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbCollapseModule, [typeof ɵngcc1.NgbCollapse], never, [typeof ɵngcc1.NgbCollapse]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbCollapseModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29sbGFwc2UubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbImNvbGxhcHNlLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBOZ2JDb2xsYXBzZSB9IGZyb20gJy4vY29sbGFwc2UnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQ29sbGFwc2VNb2R1bGUge1xufVxuIl19