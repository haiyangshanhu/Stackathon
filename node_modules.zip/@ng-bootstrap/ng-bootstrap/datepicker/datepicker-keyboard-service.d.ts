import { NgbDatepicker } from './datepicker';
/**
 * A service that represents the keyboard navigation.
 *
 * Default keyboard shortcuts [are documented in the overview](#/components/datepicker/overview#keyboard-shortcuts)
 *
 * @since 5.2.0
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbDatepickerKeyboardService {
    /**
     * Processes a keyboard event.
     */
    processKey(event: KeyboardEvent, datepicker: NgbDatepicker): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDatepickerKeyboardService, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci1rZXlib2FyZC1zZXJ2aWNlLmQudHMiLCJzb3VyY2VzIjpbImRhdGVwaWNrZXIta2V5Ym9hcmQtc2VydmljZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nYkRhdGVwaWNrZXIgfSBmcm9tICcuL2RhdGVwaWNrZXInO1xuLyoqXG4gKiBBIHNlcnZpY2UgdGhhdCByZXByZXNlbnRzIHRoZSBrZXlib2FyZCBuYXZpZ2F0aW9uLlxuICpcbiAqIERlZmF1bHQga2V5Ym9hcmQgc2hvcnRjdXRzIFthcmUgZG9jdW1lbnRlZCBpbiB0aGUgb3ZlcnZpZXddKCMvY29tcG9uZW50cy9kYXRlcGlja2VyL292ZXJ2aWV3I2tleWJvYXJkLXNob3J0Y3V0cylcbiAqXG4gKiBAc2luY2UgNS4yLjBcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiRGF0ZXBpY2tlcktleWJvYXJkU2VydmljZSB7XG4gICAgLyoqXG4gICAgICogUHJvY2Vzc2VzIGEga2V5Ym9hcmQgZXZlbnQuXG4gICAgICovXG4gICAgcHJvY2Vzc0tleShldmVudDogS2V5Ym9hcmRFdmVudCwgZGF0ZXBpY2tlcjogTmdiRGF0ZXBpY2tlcik6IHZvaWQ7XG59XG4iXX0=