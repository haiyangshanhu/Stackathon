import { NgbDatepicker } from './datepicker';
import { NgbDatepickerI18n } from './datepicker-i18n';
import { NgbDatepickerKeyboardService } from './datepicker-keyboard-service';
import { NgbDatepickerService } from './datepicker-service';
import { MonthViewModel, DayViewModel } from './datepicker-view-model';
import { NgbDateStruct } from './ngb-date-struct';
/**
 * A component that renders one month including all the days, weekdays and week numbers. Can be used inside
 * the `<ng-template ngbDatepickerMonths></ng-template>` when you want to customize months layout.
 *
 * For a usage example, see [custom month layout demo](#/components/datepicker/examples#custommonth)
 *
 * @since 5.3.0
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbDatepickerMonth {
    i18n: NgbDatepickerI18n;
    datepicker: NgbDatepicker;
    private _keyboardService;
    private _service;
    /**
     * The first date of month to be rendered.
     *
     * This month must one of the months present in the
     * [datepicker state](#/components/datepicker/api#NgbDatepickerState).
     */
    set month(month: NgbDateStruct);
    viewModel: MonthViewModel;
    constructor(i18n: NgbDatepickerI18n, datepicker: NgbDatepicker, _keyboardService: NgbDatepickerKeyboardService, _service: NgbDatepickerService);
    onKeyDown(event: KeyboardEvent): void;
    doSelect(day: DayViewModel): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDatepickerMonth, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbDatepickerMonth, "ngb-datepicker-month", never, { "month": "month"; }, {}, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci1tb250aC5kLnRzIiwic291cmNlcyI6WyJkYXRlcGlja2VyLW1vbnRoLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ2JEYXRlcGlja2VyIH0gZnJvbSAnLi9kYXRlcGlja2VyJztcbmltcG9ydCB7IE5nYkRhdGVwaWNrZXJJMThuIH0gZnJvbSAnLi9kYXRlcGlja2VyLWkxOG4nO1xuaW1wb3J0IHsgTmdiRGF0ZXBpY2tlcktleWJvYXJkU2VydmljZSB9IGZyb20gJy4vZGF0ZXBpY2tlci1rZXlib2FyZC1zZXJ2aWNlJztcbmltcG9ydCB7IE5nYkRhdGVwaWNrZXJTZXJ2aWNlIH0gZnJvbSAnLi9kYXRlcGlja2VyLXNlcnZpY2UnO1xuaW1wb3J0IHsgTW9udGhWaWV3TW9kZWwsIERheVZpZXdNb2RlbCB9IGZyb20gJy4vZGF0ZXBpY2tlci12aWV3LW1vZGVsJztcbmltcG9ydCB7IE5nYkRhdGVTdHJ1Y3QgfSBmcm9tICcuL25nYi1kYXRlLXN0cnVjdCc7XG4vKipcbiAqIEEgY29tcG9uZW50IHRoYXQgcmVuZGVycyBvbmUgbW9udGggaW5jbHVkaW5nIGFsbCB0aGUgZGF5cywgd2Vla2RheXMgYW5kIHdlZWsgbnVtYmVycy4gQ2FuIGJlIHVzZWQgaW5zaWRlXG4gKiB0aGUgYDxuZy10ZW1wbGF0ZSBuZ2JEYXRlcGlja2VyTW9udGhzPjwvbmctdGVtcGxhdGU+YCB3aGVuIHlvdSB3YW50IHRvIGN1c3RvbWl6ZSBtb250aHMgbGF5b3V0LlxuICpcbiAqIEZvciBhIHVzYWdlIGV4YW1wbGUsIHNlZSBbY3VzdG9tIG1vbnRoIGxheW91dCBkZW1vXSgjL2NvbXBvbmVudHMvZGF0ZXBpY2tlci9leGFtcGxlcyNjdXN0b21tb250aClcbiAqXG4gKiBAc2luY2UgNS4zLjBcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiRGF0ZXBpY2tlck1vbnRoIHtcbiAgICBpMThuOiBOZ2JEYXRlcGlja2VySTE4bjtcbiAgICBkYXRlcGlja2VyOiBOZ2JEYXRlcGlja2VyO1xuICAgIHByaXZhdGUgX2tleWJvYXJkU2VydmljZTtcbiAgICBwcml2YXRlIF9zZXJ2aWNlO1xuICAgIC8qKlxuICAgICAqIFRoZSBmaXJzdCBkYXRlIG9mIG1vbnRoIHRvIGJlIHJlbmRlcmVkLlxuICAgICAqXG4gICAgICogVGhpcyBtb250aCBtdXN0IG9uZSBvZiB0aGUgbW9udGhzIHByZXNlbnQgaW4gdGhlXG4gICAgICogW2RhdGVwaWNrZXIgc3RhdGVdKCMvY29tcG9uZW50cy9kYXRlcGlja2VyL2FwaSNOZ2JEYXRlcGlja2VyU3RhdGUpLlxuICAgICAqL1xuICAgIHNldCBtb250aChtb250aDogTmdiRGF0ZVN0cnVjdCk7XG4gICAgdmlld01vZGVsOiBNb250aFZpZXdNb2RlbDtcbiAgICBjb25zdHJ1Y3RvcihpMThuOiBOZ2JEYXRlcGlja2VySTE4biwgZGF0ZXBpY2tlcjogTmdiRGF0ZXBpY2tlciwgX2tleWJvYXJkU2VydmljZTogTmdiRGF0ZXBpY2tlcktleWJvYXJkU2VydmljZSwgX3NlcnZpY2U6IE5nYkRhdGVwaWNrZXJTZXJ2aWNlKTtcbiAgICBvbktleURvd24oZXZlbnQ6IEtleWJvYXJkRXZlbnQpOiB2b2lkO1xuICAgIGRvU2VsZWN0KGRheTogRGF5Vmlld01vZGVsKTogdm9pZDtcbn1cbiJdfQ==