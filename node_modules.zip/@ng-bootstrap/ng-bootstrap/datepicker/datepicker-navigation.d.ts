import { EventEmitter } from '@angular/core';
import { NavigationEvent, MonthViewModel } from './datepicker-view-model';
import { NgbDate } from './ngb-date';
import { NgbDatepickerI18n } from './datepicker-i18n';
import * as ɵngcc0 from '@angular/core';
export declare class NgbDatepickerNavigation {
    i18n: NgbDatepickerI18n;
    navigation: typeof NavigationEvent;
    date: NgbDate;
    disabled: boolean;
    months: MonthViewModel[];
    showSelect: boolean;
    prevDisabled: boolean;
    nextDisabled: boolean;
    selectBoxes: {
        years: number[];
        months: number[];
    };
    navigate: EventEmitter<NavigationEvent>;
    select: EventEmitter<NgbDate>;
    constructor(i18n: NgbDatepickerI18n);
    onClickPrev(event: MouseEvent): void;
    onClickNext(event: MouseEvent): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDatepickerNavigation, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbDatepickerNavigation, "ngb-datepicker-navigation", never, { "months": "months"; "date": "date"; "disabled": "disabled"; "showSelect": "showSelect"; "prevDisabled": "prevDisabled"; "nextDisabled": "nextDisabled"; "selectBoxes": "selectBoxes"; }, { "navigate": "navigate"; "select": "select"; }, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci1uYXZpZ2F0aW9uLmQudHMiLCJzb3VyY2VzIjpbImRhdGVwaWNrZXItbmF2aWdhdGlvbi5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5hdmlnYXRpb25FdmVudCwgTW9udGhWaWV3TW9kZWwgfSBmcm9tICcuL2RhdGVwaWNrZXItdmlldy1tb2RlbCc7XG5pbXBvcnQgeyBOZ2JEYXRlIH0gZnJvbSAnLi9uZ2ItZGF0ZSc7XG5pbXBvcnQgeyBOZ2JEYXRlcGlja2VySTE4biB9IGZyb20gJy4vZGF0ZXBpY2tlci1pMThuJztcbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYkRhdGVwaWNrZXJOYXZpZ2F0aW9uIHtcbiAgICBpMThuOiBOZ2JEYXRlcGlja2VySTE4bjtcbiAgICBuYXZpZ2F0aW9uOiB0eXBlb2YgTmF2aWdhdGlvbkV2ZW50O1xuICAgIGRhdGU6IE5nYkRhdGU7XG4gICAgZGlzYWJsZWQ6IGJvb2xlYW47XG4gICAgbW9udGhzOiBNb250aFZpZXdNb2RlbFtdO1xuICAgIHNob3dTZWxlY3Q6IGJvb2xlYW47XG4gICAgcHJldkRpc2FibGVkOiBib29sZWFuO1xuICAgIG5leHREaXNhYmxlZDogYm9vbGVhbjtcbiAgICBzZWxlY3RCb3hlczoge1xuICAgICAgICB5ZWFyczogbnVtYmVyW107XG4gICAgICAgIG1vbnRoczogbnVtYmVyW107XG4gICAgfTtcbiAgICBuYXZpZ2F0ZTogRXZlbnRFbWl0dGVyPE5hdmlnYXRpb25FdmVudD47XG4gICAgc2VsZWN0OiBFdmVudEVtaXR0ZXI8TmdiRGF0ZT47XG4gICAgY29uc3RydWN0b3IoaTE4bjogTmdiRGF0ZXBpY2tlckkxOG4pO1xuICAgIG9uQ2xpY2tQcmV2KGV2ZW50OiBNb3VzZUV2ZW50KTogdm9pZDtcbiAgICBvbkNsaWNrTmV4dChldmVudDogTW91c2VFdmVudCk6IHZvaWQ7XG59XG4iXX0=