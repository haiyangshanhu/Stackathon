import { NgbDatepickerI18n } from '../datepicker-i18n';
import { NgbDateStruct } from '../../index';
/**
 * @since 3.2.0
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbDatepickerI18nHebrew extends NgbDatepickerI18n {
    getMonthShortName(month: number, year?: number): string;
    getMonthFullName(month: number, year?: number): string;
    getWeekdayShortName(weekday: number): string;
    getDayAriaLabel(date: NgbDateStruct): string;
    getDayNumerals(date: NgbDateStruct): string;
    getWeekNumerals(weekNumber: number): string;
    getYearNumerals(year: number): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDatepickerI18nHebrew, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NgbDatepickerI18nHebrew>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci1pMThuLWhlYnJldy5kLnRzIiwic291cmNlcyI6WyJkYXRlcGlja2VyLWkxOG4taGVicmV3LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5nYkRhdGVwaWNrZXJJMThuIH0gZnJvbSAnLi4vZGF0ZXBpY2tlci1pMThuJztcbmltcG9ydCB7IE5nYkRhdGVTdHJ1Y3QgfSBmcm9tICcuLi8uLi9pbmRleCc7XG4vKipcbiAqIEBzaW5jZSAzLjIuMFxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JEYXRlcGlja2VySTE4bkhlYnJldyBleHRlbmRzIE5nYkRhdGVwaWNrZXJJMThuIHtcbiAgICBnZXRNb250aFNob3J0TmFtZShtb250aDogbnVtYmVyLCB5ZWFyPzogbnVtYmVyKTogc3RyaW5nO1xuICAgIGdldE1vbnRoRnVsbE5hbWUobW9udGg6IG51bWJlciwgeWVhcj86IG51bWJlcik6IHN0cmluZztcbiAgICBnZXRXZWVrZGF5U2hvcnROYW1lKHdlZWtkYXk6IG51bWJlcik6IHN0cmluZztcbiAgICBnZXREYXlBcmlhTGFiZWwoZGF0ZTogTmdiRGF0ZVN0cnVjdCk6IHN0cmluZztcbiAgICBnZXREYXlOdW1lcmFscyhkYXRlOiBOZ2JEYXRlU3RydWN0KTogc3RyaW5nO1xuICAgIGdldFdlZWtOdW1lcmFscyh3ZWVrTnVtYmVyOiBudW1iZXIpOiBzdHJpbmc7XG4gICAgZ2V0WWVhck51bWVyYWxzKHllYXI6IG51bWJlcik6IHN0cmluZztcbn1cbiJdfQ==