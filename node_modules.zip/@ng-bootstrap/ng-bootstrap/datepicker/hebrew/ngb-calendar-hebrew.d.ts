import { NgbDate } from '../ngb-date';
import { NgbCalendar, NgbPeriod } from '../ngb-calendar';
/**
 * @since 3.2.0
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbCalendarHebrew extends NgbCalendar {
    getDaysPerWeek(): number;
    getMonths(year?: number): number[];
    getWeeksPerMonth(): number;
    isValid(date?: NgbDate | null): boolean;
    getNext(date: NgbDate, period?: NgbPeriod, number?: number): NgbDate;
    getPrev(date: NgbDate, period?: NgbPeriod, number?: number): NgbDate;
    getWeekday(date: NgbDate): number;
    getWeekNumber(week: readonly NgbDate[], firstDayOfWeek: number): number;
    getToday(): NgbDate;
    /**
     * @since 3.4.0
     */
    toGregorian(date: NgbDate): NgbDate;
    /**
     * @since 3.4.0
     */
    fromGregorian(date: NgbDate): NgbDate;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbCalendarHebrew, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NgbCalendarHebrew>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmdiLWNhbGVuZGFyLWhlYnJldy5kLnRzIiwic291cmNlcyI6WyJuZ2ItY2FsZW5kYXItaGVicmV3LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdiRGF0ZSB9IGZyb20gJy4uL25nYi1kYXRlJztcbmltcG9ydCB7IE5nYkNhbGVuZGFyLCBOZ2JQZXJpb2QgfSBmcm9tICcuLi9uZ2ItY2FsZW5kYXInO1xuLyoqXG4gKiBAc2luY2UgMy4yLjBcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiQ2FsZW5kYXJIZWJyZXcgZXh0ZW5kcyBOZ2JDYWxlbmRhciB7XG4gICAgZ2V0RGF5c1BlcldlZWsoKTogbnVtYmVyO1xuICAgIGdldE1vbnRocyh5ZWFyPzogbnVtYmVyKTogbnVtYmVyW107XG4gICAgZ2V0V2Vla3NQZXJNb250aCgpOiBudW1iZXI7XG4gICAgaXNWYWxpZChkYXRlPzogTmdiRGF0ZSB8IG51bGwpOiBib29sZWFuO1xuICAgIGdldE5leHQoZGF0ZTogTmdiRGF0ZSwgcGVyaW9kPzogTmdiUGVyaW9kLCBudW1iZXI/OiBudW1iZXIpOiBOZ2JEYXRlO1xuICAgIGdldFByZXYoZGF0ZTogTmdiRGF0ZSwgcGVyaW9kPzogTmdiUGVyaW9kLCBudW1iZXI/OiBudW1iZXIpOiBOZ2JEYXRlO1xuICAgIGdldFdlZWtkYXkoZGF0ZTogTmdiRGF0ZSk6IG51bWJlcjtcbiAgICBnZXRXZWVrTnVtYmVyKHdlZWs6IHJlYWRvbmx5IE5nYkRhdGVbXSwgZmlyc3REYXlPZldlZWs6IG51bWJlcik6IG51bWJlcjtcbiAgICBnZXRUb2RheSgpOiBOZ2JEYXRlO1xuICAgIC8qKlxuICAgICAqIEBzaW5jZSAzLjQuMFxuICAgICAqL1xuICAgIHRvR3JlZ29yaWFuKGRhdGU6IE5nYkRhdGUpOiBOZ2JEYXRlO1xuICAgIC8qKlxuICAgICAqIEBzaW5jZSAzLjQuMFxuICAgICAqL1xuICAgIGZyb21HcmVnb3JpYW4oZGF0ZTogTmdiRGF0ZSk6IE5nYkRhdGU7XG59XG4iXX0=