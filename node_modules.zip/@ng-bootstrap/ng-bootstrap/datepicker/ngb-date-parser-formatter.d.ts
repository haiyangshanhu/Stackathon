import { NgbDateStruct } from './ngb-date-struct';
import * as ɵngcc0 from '@angular/core';
export declare function NGB_DATEPICKER_PARSER_FORMATTER_FACTORY(): NgbDateISOParserFormatter;
/**
 * An abstract service for parsing and formatting dates for the
 * [`NgbInputDatepicker`](#/components/datepicker/api#NgbInputDatepicker) directive.
 * Converts between the internal `NgbDateStruct` model presentation and a `string` that is displayed in the
 * input element.
 *
 * When user types something in the input this service attempts to parse it into a `NgbDateStruct` object.
 * And vice versa, when users selects a date in the calendar with the mouse, it must be displayed as a `string`
 * in the input.
 *
 * Default implementation uses the ISO 8601 format, but you can provide another implementation via DI
 * to use an alternative string format or a custom parsing logic.
 *
 * See the [date format overview](#/components/datepicker/overview#date-model) for more details.
 */
export declare abstract class NgbDateParserFormatter {
    /**
     * Parses the given `string` to an `NgbDateStruct`.
     *
     * Implementations should try their best to provide a result, even
     * partial. They must return `null` if the value can't be parsed.
     */
    abstract parse(value: string): NgbDateStruct | null;
    /**
     * Formats the given `NgbDateStruct` to a `string`.
     *
     * Implementations should return an empty string if the given date is `null`,
     * and try their best to provide a partial result if the given date is incomplete or invalid.
     */
    abstract format(date: NgbDateStruct | null): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDateParserFormatter, never>;
}
export declare class NgbDateISOParserFormatter extends NgbDateParserFormatter {
    parse(value: string): NgbDateStruct | null;
    format(date: NgbDateStruct | null): string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbDateISOParserFormatter, never>;
    static ɵprov: ɵngcc0.ɵɵInjectableDef<NgbDateISOParserFormatter>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmdiLWRhdGUtcGFyc2VyLWZvcm1hdHRlci5kLnRzIiwic291cmNlcyI6WyJuZ2ItZGF0ZS1wYXJzZXItZm9ybWF0dGVyLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdiRGF0ZVN0cnVjdCB9IGZyb20gJy4vbmdiLWRhdGUtc3RydWN0JztcbmV4cG9ydCBkZWNsYXJlIGZ1bmN0aW9uIE5HQl9EQVRFUElDS0VSX1BBUlNFUl9GT1JNQVRURVJfRkFDVE9SWSgpOiBOZ2JEYXRlSVNPUGFyc2VyRm9ybWF0dGVyO1xuLyoqXG4gKiBBbiBhYnN0cmFjdCBzZXJ2aWNlIGZvciBwYXJzaW5nIGFuZCBmb3JtYXR0aW5nIGRhdGVzIGZvciB0aGVcbiAqIFtgTmdiSW5wdXREYXRlcGlja2VyYF0oIy9jb21wb25lbnRzL2RhdGVwaWNrZXIvYXBpI05nYklucHV0RGF0ZXBpY2tlcikgZGlyZWN0aXZlLlxuICogQ29udmVydHMgYmV0d2VlbiB0aGUgaW50ZXJuYWwgYE5nYkRhdGVTdHJ1Y3RgIG1vZGVsIHByZXNlbnRhdGlvbiBhbmQgYSBgc3RyaW5nYCB0aGF0IGlzIGRpc3BsYXllZCBpbiB0aGVcbiAqIGlucHV0IGVsZW1lbnQuXG4gKlxuICogV2hlbiB1c2VyIHR5cGVzIHNvbWV0aGluZyBpbiB0aGUgaW5wdXQgdGhpcyBzZXJ2aWNlIGF0dGVtcHRzIHRvIHBhcnNlIGl0IGludG8gYSBgTmdiRGF0ZVN0cnVjdGAgb2JqZWN0LlxuICogQW5kIHZpY2UgdmVyc2EsIHdoZW4gdXNlcnMgc2VsZWN0cyBhIGRhdGUgaW4gdGhlIGNhbGVuZGFyIHdpdGggdGhlIG1vdXNlLCBpdCBtdXN0IGJlIGRpc3BsYXllZCBhcyBhIGBzdHJpbmdgXG4gKiBpbiB0aGUgaW5wdXQuXG4gKlxuICogRGVmYXVsdCBpbXBsZW1lbnRhdGlvbiB1c2VzIHRoZSBJU08gODYwMSBmb3JtYXQsIGJ1dCB5b3UgY2FuIHByb3ZpZGUgYW5vdGhlciBpbXBsZW1lbnRhdGlvbiB2aWEgRElcbiAqIHRvIHVzZSBhbiBhbHRlcm5hdGl2ZSBzdHJpbmcgZm9ybWF0IG9yIGEgY3VzdG9tIHBhcnNpbmcgbG9naWMuXG4gKlxuICogU2VlIHRoZSBbZGF0ZSBmb3JtYXQgb3ZlcnZpZXddKCMvY29tcG9uZW50cy9kYXRlcGlja2VyL292ZXJ2aWV3I2RhdGUtbW9kZWwpIGZvciBtb3JlIGRldGFpbHMuXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGFic3RyYWN0IGNsYXNzIE5nYkRhdGVQYXJzZXJGb3JtYXR0ZXIge1xuICAgIC8qKlxuICAgICAqIFBhcnNlcyB0aGUgZ2l2ZW4gYHN0cmluZ2AgdG8gYW4gYE5nYkRhdGVTdHJ1Y3RgLlxuICAgICAqXG4gICAgICogSW1wbGVtZW50YXRpb25zIHNob3VsZCB0cnkgdGhlaXIgYmVzdCB0byBwcm92aWRlIGEgcmVzdWx0LCBldmVuXG4gICAgICogcGFydGlhbC4gVGhleSBtdXN0IHJldHVybiBgbnVsbGAgaWYgdGhlIHZhbHVlIGNhbid0IGJlIHBhcnNlZC5cbiAgICAgKi9cbiAgICBhYnN0cmFjdCBwYXJzZSh2YWx1ZTogc3RyaW5nKTogTmdiRGF0ZVN0cnVjdCB8IG51bGw7XG4gICAgLyoqXG4gICAgICogRm9ybWF0cyB0aGUgZ2l2ZW4gYE5nYkRhdGVTdHJ1Y3RgIHRvIGEgYHN0cmluZ2AuXG4gICAgICpcbiAgICAgKiBJbXBsZW1lbnRhdGlvbnMgc2hvdWxkIHJldHVybiBhbiBlbXB0eSBzdHJpbmcgaWYgdGhlIGdpdmVuIGRhdGUgaXMgYG51bGxgLFxuICAgICAqIGFuZCB0cnkgdGhlaXIgYmVzdCB0byBwcm92aWRlIGEgcGFydGlhbCByZXN1bHQgaWYgdGhlIGdpdmVuIGRhdGUgaXMgaW5jb21wbGV0ZSBvciBpbnZhbGlkLlxuICAgICAqL1xuICAgIGFic3RyYWN0IGZvcm1hdChkYXRlOiBOZ2JEYXRlU3RydWN0IHwgbnVsbCk6IHN0cmluZztcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYkRhdGVJU09QYXJzZXJGb3JtYXR0ZXIgZXh0ZW5kcyBOZ2JEYXRlUGFyc2VyRm9ybWF0dGVyIHtcbiAgICBwYXJzZSh2YWx1ZTogc3RyaW5nKTogTmdiRGF0ZVN0cnVjdCB8IG51bGw7XG4gICAgZm9ybWF0KGRhdGU6IE5nYkRhdGVTdHJ1Y3QgfCBudWxsKTogc3RyaW5nO1xufVxuIl19