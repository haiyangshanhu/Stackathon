import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './dropdown';
export { NgbDropdown, NgbDropdownAnchor, NgbDropdownToggle, NgbDropdownMenu, NgbDropdownItem, NgbNavbar } from './dropdown';
export { NgbDropdownConfig } from './dropdown-config';
export declare class NgbDropdownModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbDropdownModule, [typeof ɵngcc1.NgbDropdown, typeof ɵngcc1.NgbDropdownAnchor, typeof ɵngcc1.NgbDropdownToggle, typeof ɵngcc1.NgbDropdownMenu, typeof ɵngcc1.NgbDropdownItem, typeof ɵngcc1.NgbNavbar], never, [typeof ɵngcc1.NgbDropdown, typeof ɵngcc1.NgbDropdownAnchor, typeof ɵngcc1.NgbDropdownToggle, typeof ɵngcc1.NgbDropdownMenu, typeof ɵngcc1.NgbDropdownItem, typeof ɵngcc1.NgbNavbar]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbDropdownModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHJvcGRvd24ubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbImRyb3Bkb3duLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQUE7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IE5nYkRyb3Bkb3duLCBOZ2JEcm9wZG93bkFuY2hvciwgTmdiRHJvcGRvd25Ub2dnbGUsIE5nYkRyb3Bkb3duTWVudSwgTmdiRHJvcGRvd25JdGVtLCBOZ2JOYXZiYXIgfSBmcm9tICcuL2Ryb3Bkb3duJztcbmV4cG9ydCB7IE5nYkRyb3Bkb3duQ29uZmlnIH0gZnJvbSAnLi9kcm9wZG93bi1jb25maWcnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiRHJvcGRvd25Nb2R1bGUge1xufVxuIl19