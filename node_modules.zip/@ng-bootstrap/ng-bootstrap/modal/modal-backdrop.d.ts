import * as ɵngcc0 from '@angular/core';
export declare class NgbModalBackdrop {
    backdropClass: string;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbModalBackdrop, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbModalBackdrop, "ngb-modal-backdrop", never, { "backdropClass": "backdropClass"; }, {}, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwtYmFja2Ryb3AuZC50cyIsInNvdXJjZXMiOlsibW9kYWwtYmFja2Ryb3AuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JNb2RhbEJhY2tkcm9wIHtcbiAgICBiYWNrZHJvcENsYXNzOiBzdHJpbmc7XG59XG4iXX0=