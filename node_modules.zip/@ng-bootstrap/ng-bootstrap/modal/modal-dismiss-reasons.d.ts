export declare enum ModalDismissReasons {
    BACKDROP_CLICK = 0,
    ESC = 1
}
