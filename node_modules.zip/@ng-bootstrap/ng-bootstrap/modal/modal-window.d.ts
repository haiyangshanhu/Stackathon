import { AfterViewInit, ElementRef, EventEmitter, NgZone, OnDestroy, OnInit } from '@angular/core';
import * as ɵngcc0 from '@angular/core';
export declare class NgbModalWindow implements OnInit, AfterViewInit, OnDestroy {
    private _document;
    private _elRef;
    private _zone;
    private _closed$;
    private _elWithFocus;
    private _dialogEl;
    ariaLabelledBy: string;
    backdrop: boolean | string;
    centered: string;
    keyboard: boolean;
    scrollable: string;
    size: string;
    windowClass: string;
    dismissEvent: EventEmitter<any>;
    constructor(_document: any, _elRef: ElementRef<HTMLElement>, _zone: NgZone);
    dismiss(reason: any): void;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbModalWindow, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbModalWindow, "ngb-modal-window", never, { "backdrop": "backdrop"; "keyboard": "keyboard"; "ariaLabelledBy": "ariaLabelledBy"; "centered": "centered"; "scrollable": "scrollable"; "size": "size"; "windowClass": "windowClass"; }, { "dismissEvent": "dismiss"; }, never, ["*"]>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwtd2luZG93LmQudHMiLCJzb3VyY2VzIjpbIm1vZGFsLXdpbmRvdy5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQWZ0ZXJWaWV3SW5pdCwgRWxlbWVudFJlZiwgRXZlbnRFbWl0dGVyLCBOZ1pvbmUsIE9uRGVzdHJveSwgT25Jbml0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JNb2RhbFdpbmRvdyBpbXBsZW1lbnRzIE9uSW5pdCwgQWZ0ZXJWaWV3SW5pdCwgT25EZXN0cm95IHtcbiAgICBwcml2YXRlIF9kb2N1bWVudDtcbiAgICBwcml2YXRlIF9lbFJlZjtcbiAgICBwcml2YXRlIF96b25lO1xuICAgIHByaXZhdGUgX2Nsb3NlZCQ7XG4gICAgcHJpdmF0ZSBfZWxXaXRoRm9jdXM7XG4gICAgcHJpdmF0ZSBfZGlhbG9nRWw7XG4gICAgYXJpYUxhYmVsbGVkQnk6IHN0cmluZztcbiAgICBiYWNrZHJvcDogYm9vbGVhbiB8IHN0cmluZztcbiAgICBjZW50ZXJlZDogc3RyaW5nO1xuICAgIGtleWJvYXJkOiBib29sZWFuO1xuICAgIHNjcm9sbGFibGU6IHN0cmluZztcbiAgICBzaXplOiBzdHJpbmc7XG4gICAgd2luZG93Q2xhc3M6IHN0cmluZztcbiAgICBkaXNtaXNzRXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+O1xuICAgIGNvbnN0cnVjdG9yKF9kb2N1bWVudDogYW55LCBfZWxSZWY6IEVsZW1lbnRSZWY8SFRNTEVsZW1lbnQ+LCBfem9uZTogTmdab25lKTtcbiAgICBkaXNtaXNzKHJlYXNvbjogYW55KTogdm9pZDtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xuICAgIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkO1xuICAgIG5nT25EZXN0cm95KCk6IHZvaWQ7XG59XG4iXX0=