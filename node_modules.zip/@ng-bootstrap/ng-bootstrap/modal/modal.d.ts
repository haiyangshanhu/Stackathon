import { Injector, ComponentFactoryResolver } from '@angular/core';
import { NgbModalOptions, NgbModalConfig } from './modal-config';
import { NgbModalRef } from './modal-ref';
import { NgbModalStack } from './modal-stack';
/**
 * A service for opening modal windows.
 *
 * Creating a modal is straightforward: create a component or a template and pass it as an argument to
 * the `.open()` method.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbModal {
    private _moduleCFR;
    private _injector;
    private _modalStack;
    private _config;
    constructor(_moduleCFR: ComponentFactoryResolver, _injector: Injector, _modalStack: NgbModalStack, _config: NgbModalConfig);
    /**
     * Opens a new modal window with the specified content and supplied options.
     *
     * Content can be provided as a `TemplateRef` or a component type. If you pass a component type as content,
     * then instances of those components can be injected with an instance of the `NgbActiveModal` class. You can then
     * use `NgbActiveModal` methods to close / dismiss modals from "inside" of your component.
     *
     * Also see the [`NgbModalOptions`](#/components/modal/api#NgbModalOptions) for the list of supported options.
     */
    open(content: any, options?: NgbModalOptions): NgbModalRef;
    /**
     * Dismisses all currently displayed modal windows with the supplied reason.
     *
     * @since 3.1.0
     */
    dismissAll(reason?: any): void;
    /**
     * Indicates if there are currently any open modal windows in the application.
     *
     * @since 3.3.0
     */
    hasOpenModals(): boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbModal, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwuZC50cyIsInNvdXJjZXMiOlsibW9kYWwuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdG9yLCBDb21wb25lbnRGYWN0b3J5UmVzb2x2ZXIgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IE5nYk1vZGFsT3B0aW9ucywgTmdiTW9kYWxDb25maWcgfSBmcm9tICcuL21vZGFsLWNvbmZpZyc7XG5pbXBvcnQgeyBOZ2JNb2RhbFJlZiB9IGZyb20gJy4vbW9kYWwtcmVmJztcbmltcG9ydCB7IE5nYk1vZGFsU3RhY2sgfSBmcm9tICcuL21vZGFsLXN0YWNrJztcbi8qKlxuICogQSBzZXJ2aWNlIGZvciBvcGVuaW5nIG1vZGFsIHdpbmRvd3MuXG4gKlxuICogQ3JlYXRpbmcgYSBtb2RhbCBpcyBzdHJhaWdodGZvcndhcmQ6IGNyZWF0ZSBhIGNvbXBvbmVudCBvciBhIHRlbXBsYXRlIGFuZCBwYXNzIGl0IGFzIGFuIGFyZ3VtZW50IHRvXG4gKiB0aGUgYC5vcGVuKClgIG1ldGhvZC5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiTW9kYWwge1xuICAgIHByaXZhdGUgX21vZHVsZUNGUjtcbiAgICBwcml2YXRlIF9pbmplY3RvcjtcbiAgICBwcml2YXRlIF9tb2RhbFN0YWNrO1xuICAgIHByaXZhdGUgX2NvbmZpZztcbiAgICBjb25zdHJ1Y3RvcihfbW9kdWxlQ0ZSOiBDb21wb25lbnRGYWN0b3J5UmVzb2x2ZXIsIF9pbmplY3RvcjogSW5qZWN0b3IsIF9tb2RhbFN0YWNrOiBOZ2JNb2RhbFN0YWNrLCBfY29uZmlnOiBOZ2JNb2RhbENvbmZpZyk7XG4gICAgLyoqXG4gICAgICogT3BlbnMgYSBuZXcgbW9kYWwgd2luZG93IHdpdGggdGhlIHNwZWNpZmllZCBjb250ZW50IGFuZCBzdXBwbGllZCBvcHRpb25zLlxuICAgICAqXG4gICAgICogQ29udGVudCBjYW4gYmUgcHJvdmlkZWQgYXMgYSBgVGVtcGxhdGVSZWZgIG9yIGEgY29tcG9uZW50IHR5cGUuIElmIHlvdSBwYXNzIGEgY29tcG9uZW50IHR5cGUgYXMgY29udGVudCxcbiAgICAgKiB0aGVuIGluc3RhbmNlcyBvZiB0aG9zZSBjb21wb25lbnRzIGNhbiBiZSBpbmplY3RlZCB3aXRoIGFuIGluc3RhbmNlIG9mIHRoZSBgTmdiQWN0aXZlTW9kYWxgIGNsYXNzLiBZb3UgY2FuIHRoZW5cbiAgICAgKiB1c2UgYE5nYkFjdGl2ZU1vZGFsYCBtZXRob2RzIHRvIGNsb3NlIC8gZGlzbWlzcyBtb2RhbHMgZnJvbSBcImluc2lkZVwiIG9mIHlvdXIgY29tcG9uZW50LlxuICAgICAqXG4gICAgICogQWxzbyBzZWUgdGhlIFtgTmdiTW9kYWxPcHRpb25zYF0oIy9jb21wb25lbnRzL21vZGFsL2FwaSNOZ2JNb2RhbE9wdGlvbnMpIGZvciB0aGUgbGlzdCBvZiBzdXBwb3J0ZWQgb3B0aW9ucy5cbiAgICAgKi9cbiAgICBvcGVuKGNvbnRlbnQ6IGFueSwgb3B0aW9ucz86IE5nYk1vZGFsT3B0aW9ucyk6IE5nYk1vZGFsUmVmO1xuICAgIC8qKlxuICAgICAqIERpc21pc3NlcyBhbGwgY3VycmVudGx5IGRpc3BsYXllZCBtb2RhbCB3aW5kb3dzIHdpdGggdGhlIHN1cHBsaWVkIHJlYXNvbi5cbiAgICAgKlxuICAgICAqIEBzaW5jZSAzLjEuMFxuICAgICAqL1xuICAgIGRpc21pc3NBbGwocmVhc29uPzogYW55KTogdm9pZDtcbiAgICAvKipcbiAgICAgKiBJbmRpY2F0ZXMgaWYgdGhlcmUgYXJlIGN1cnJlbnRseSBhbnkgb3BlbiBtb2RhbCB3aW5kb3dzIGluIHRoZSBhcHBsaWNhdGlvbi5cbiAgICAgKlxuICAgICAqIEBzaW5jZSAzLjMuMFxuICAgICAqL1xuICAgIGhhc09wZW5Nb2RhbHMoKTogYm9vbGVhbjtcbn1cbiJdfQ==