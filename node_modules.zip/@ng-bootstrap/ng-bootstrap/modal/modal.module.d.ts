import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './modal-backdrop';
import * as ɵngcc2 from './modal-window';
export { NgbModal } from './modal';
export { NgbModalConfig, NgbModalOptions } from './modal-config';
export { NgbModalRef, NgbActiveModal } from './modal-ref';
export { ModalDismissReasons } from './modal-dismiss-reasons';
export declare class NgbModalModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbModalModule, [typeof ɵngcc1.NgbModalBackdrop, typeof ɵngcc2.NgbModalWindow], never, never>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbModalModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbIm1vZGFsLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgTmdiTW9kYWwgfSBmcm9tICcuL21vZGFsJztcbmV4cG9ydCB7IE5nYk1vZGFsQ29uZmlnLCBOZ2JNb2RhbE9wdGlvbnMgfSBmcm9tICcuL21vZGFsLWNvbmZpZyc7XG5leHBvcnQgeyBOZ2JNb2RhbFJlZiwgTmdiQWN0aXZlTW9kYWwgfSBmcm9tICcuL21vZGFsLXJlZic7XG5leHBvcnQgeyBNb2RhbERpc21pc3NSZWFzb25zIH0gZnJvbSAnLi9tb2RhbC1kaXNtaXNzLXJlYXNvbnMnO1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiTW9kYWxNb2R1bGUge1xufVxuIl19