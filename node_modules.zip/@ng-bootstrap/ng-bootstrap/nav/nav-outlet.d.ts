import { NgbNav } from './nav';
/**
 * The outlet where currently active nav content will be displayed.
 *
 * @since 5.2.0
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbNavOutlet {
    /**
     * A role to set on the nav pane
     */
    paneRole: any;
    /**
     * Reference to the `NgbNav`
     */
    nav: NgbNav;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbNavOutlet, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbNavOutlet, "[ngbNavOutlet]", never, { "paneRole": "paneRole"; "nav": "ngbNavOutlet"; }, {}, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmF2LW91dGxldC5kLnRzIiwic291cmNlcyI6WyJuYXYtb3V0bGV0LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ2JOYXYgfSBmcm9tICcuL25hdic7XG4vKipcbiAqIFRoZSBvdXRsZXQgd2hlcmUgY3VycmVudGx5IGFjdGl2ZSBuYXYgY29udGVudCB3aWxsIGJlIGRpc3BsYXllZC5cbiAqXG4gKiBAc2luY2UgNS4yLjBcbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiTmF2T3V0bGV0IHtcbiAgICAvKipcbiAgICAgKiBBIHJvbGUgdG8gc2V0IG9uIHRoZSBuYXYgcGFuZVxuICAgICAqL1xuICAgIHBhbmVSb2xlOiBhbnk7XG4gICAgLyoqXG4gICAgICogUmVmZXJlbmNlIHRvIHRoZSBgTmdiTmF2YFxuICAgICAqL1xuICAgIG5hdjogTmdiTmF2O1xufVxuIl19