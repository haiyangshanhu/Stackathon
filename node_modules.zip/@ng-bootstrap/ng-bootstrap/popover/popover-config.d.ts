import { PlacementArray } from '../util/positioning';
/**
 * A configuration service for the [`NgbPopover`](#/components/popover/api#NgbPopover) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the popovers used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbPopoverConfig {
    autoClose: boolean | 'inside' | 'outside';
    placement: PlacementArray;
    triggers: string;
    container: string;
    disablePopover: boolean;
    popoverClass: string;
    openDelay: number;
    closeDelay: number;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbPopoverConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9wb3Zlci1jb25maWcuZC50cyIsInNvdXJjZXMiOlsicG9wb3Zlci1jb25maWcuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbGFjZW1lbnRBcnJheSB9IGZyb20gJy4uL3V0aWwvcG9zaXRpb25pbmcnO1xuLyoqXG4gKiBBIGNvbmZpZ3VyYXRpb24gc2VydmljZSBmb3IgdGhlIFtgTmdiUG9wb3ZlcmBdKCMvY29tcG9uZW50cy9wb3BvdmVyL2FwaSNOZ2JQb3BvdmVyKSBjb21wb25lbnQuXG4gKlxuICogWW91IGNhbiBpbmplY3QgdGhpcyBzZXJ2aWNlLCB0eXBpY2FsbHkgaW4geW91ciByb290IGNvbXBvbmVudCwgYW5kIGN1c3RvbWl6ZSB0aGUgdmFsdWVzIG9mIGl0cyBwcm9wZXJ0aWVzIGluXG4gKiBvcmRlciB0byBwcm92aWRlIGRlZmF1bHQgdmFsdWVzIGZvciBhbGwgdGhlIHBvcG92ZXJzIHVzZWQgaW4gdGhlIGFwcGxpY2F0aW9uLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JQb3BvdmVyQ29uZmlnIHtcbiAgICBhdXRvQ2xvc2U6IGJvb2xlYW4gfCAnaW5zaWRlJyB8ICdvdXRzaWRlJztcbiAgICBwbGFjZW1lbnQ6IFBsYWNlbWVudEFycmF5O1xuICAgIHRyaWdnZXJzOiBzdHJpbmc7XG4gICAgY29udGFpbmVyOiBzdHJpbmc7XG4gICAgZGlzYWJsZVBvcG92ZXI6IGJvb2xlYW47XG4gICAgcG9wb3ZlckNsYXNzOiBzdHJpbmc7XG4gICAgb3BlbkRlbGF5OiBudW1iZXI7XG4gICAgY2xvc2VEZWxheTogbnVtYmVyO1xufVxuIl19