import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './progressbar';
import * as ɵngcc2 from '@angular/common';
export { NgbProgressbar } from './progressbar';
export { NgbProgressbarConfig } from './progressbar-config';
export declare class NgbProgressbarModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbProgressbarModule, [typeof ɵngcc1.NgbProgressbar], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbProgressbar]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbProgressbarModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJvZ3Jlc3NiYXIubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbInByb2dyZXNzYmFyLm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBOZ2JQcm9ncmVzc2JhciB9IGZyb20gJy4vcHJvZ3Jlc3NiYXInO1xuZXhwb3J0IHsgTmdiUHJvZ3Jlc3NiYXJDb25maWcgfSBmcm9tICcuL3Byb2dyZXNzYmFyLWNvbmZpZyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JQcm9ncmVzc2Jhck1vZHVsZSB7XG59XG4iXX0=