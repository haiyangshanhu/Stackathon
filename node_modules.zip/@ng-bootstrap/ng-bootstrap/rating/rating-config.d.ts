/**
 * A configuration service for the [`NgbRating`](#/components/rating/api#NgbRating) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the ratings used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbRatingConfig {
    max: number;
    readonly: boolean;
    resettable: boolean;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbRatingConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF0aW5nLWNvbmZpZy5kLnRzIiwic291cmNlcyI6WyJyYXRpbmctY29uZmlnLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBIGNvbmZpZ3VyYXRpb24gc2VydmljZSBmb3IgdGhlIFtgTmdiUmF0aW5nYF0oIy9jb21wb25lbnRzL3JhdGluZy9hcGkjTmdiUmF0aW5nKSBjb21wb25lbnQuXG4gKlxuICogWW91IGNhbiBpbmplY3QgdGhpcyBzZXJ2aWNlLCB0eXBpY2FsbHkgaW4geW91ciByb290IGNvbXBvbmVudCwgYW5kIGN1c3RvbWl6ZSB0aGUgdmFsdWVzIG9mIGl0cyBwcm9wZXJ0aWVzIGluXG4gKiBvcmRlciB0byBwcm92aWRlIGRlZmF1bHQgdmFsdWVzIGZvciBhbGwgdGhlIHJhdGluZ3MgdXNlZCBpbiB0aGUgYXBwbGljYXRpb24uXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlJhdGluZ0NvbmZpZyB7XG4gICAgbWF4OiBudW1iZXI7XG4gICAgcmVhZG9ubHk6IGJvb2xlYW47XG4gICAgcmVzZXR0YWJsZTogYm9vbGVhbjtcbn1cbiJdfQ==