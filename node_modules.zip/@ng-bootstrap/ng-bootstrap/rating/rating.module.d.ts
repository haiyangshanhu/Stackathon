import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './rating';
import * as ɵngcc2 from '@angular/common';
export { NgbRating } from './rating';
export { NgbRatingConfig } from './rating-config';
export declare class NgbRatingModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbRatingModule, [typeof ɵngcc1.NgbRating], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbRating]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbRatingModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmF0aW5nLm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJyYXRpbmcubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IE5nYlJhdGluZyB9IGZyb20gJy4vcmF0aW5nJztcbmV4cG9ydCB7IE5nYlJhdGluZ0NvbmZpZyB9IGZyb20gJy4vcmF0aW5nLWNvbmZpZyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JSYXRpbmdNb2R1bGUge1xufVxuIl19