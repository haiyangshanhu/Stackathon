import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './tabset';
import * as ɵngcc2 from '@angular/common';
export { NgbTabset, NgbTab, NgbTabContent, NgbTabTitle, NgbTabChangeEvent } from './tabset';
export { NgbTabsetConfig } from './tabset-config';
/**
 * @deprecated 6.0.0 Please use NgbNavModule instead
 */
export declare class NgbTabsetModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbTabsetModule, [typeof ɵngcc1.NgbTabset, typeof ɵngcc1.NgbTab, typeof ɵngcc1.NgbTabContent, typeof ɵngcc1.NgbTabTitle], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbTabset, typeof ɵngcc1.NgbTab, typeof ɵngcc1.NgbTabContent, typeof ɵngcc1.NgbTabTitle]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbTabsetModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGFic2V0Lm1vZHVsZS5kLnRzIiwic291cmNlcyI6WyJ0YWJzZXQubW9kdWxlLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCB7IE5nYlRhYnNldCwgTmdiVGFiLCBOZ2JUYWJDb250ZW50LCBOZ2JUYWJUaXRsZSwgTmdiVGFiQ2hhbmdlRXZlbnQgfSBmcm9tICcuL3RhYnNldCc7XG5leHBvcnQgeyBOZ2JUYWJzZXRDb25maWcgfSBmcm9tICcuL3RhYnNldC1jb25maWcnO1xuLyoqXG4gKiBAZGVwcmVjYXRlZCA2LjAuMCBQbGVhc2UgdXNlIE5nYk5hdk1vZHVsZSBpbnN0ZWFkXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlRhYnNldE1vZHVsZSB7XG59XG4iXX0=