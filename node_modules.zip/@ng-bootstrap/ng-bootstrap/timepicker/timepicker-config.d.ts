/**
 * A configuration service for the [`NgbTimepicker`](#/components/timepicker/api#NgbTimepicker) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the timepickers used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbTimepickerConfig {
    meridian: boolean;
    spinners: boolean;
    seconds: boolean;
    hourStep: number;
    minuteStep: number;
    secondStep: number;
    disabled: boolean;
    readonlyInputs: boolean;
    size: 'small' | 'medium' | 'large';
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbTimepickerConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXBpY2tlci1jb25maWcuZC50cyIsInNvdXJjZXMiOlsidGltZXBpY2tlci1jb25maWcuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEEgY29uZmlndXJhdGlvbiBzZXJ2aWNlIGZvciB0aGUgW2BOZ2JUaW1lcGlja2VyYF0oIy9jb21wb25lbnRzL3RpbWVwaWNrZXIvYXBpI05nYlRpbWVwaWNrZXIpIGNvbXBvbmVudC5cbiAqXG4gKiBZb3UgY2FuIGluamVjdCB0aGlzIHNlcnZpY2UsIHR5cGljYWxseSBpbiB5b3VyIHJvb3QgY29tcG9uZW50LCBhbmQgY3VzdG9taXplIHRoZSB2YWx1ZXMgb2YgaXRzIHByb3BlcnRpZXMgaW5cbiAqIG9yZGVyIHRvIHByb3ZpZGUgZGVmYXVsdCB2YWx1ZXMgZm9yIGFsbCB0aGUgdGltZXBpY2tlcnMgdXNlZCBpbiB0aGUgYXBwbGljYXRpb24uXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlRpbWVwaWNrZXJDb25maWcge1xuICAgIG1lcmlkaWFuOiBib29sZWFuO1xuICAgIHNwaW5uZXJzOiBib29sZWFuO1xuICAgIHNlY29uZHM6IGJvb2xlYW47XG4gICAgaG91clN0ZXA6IG51bWJlcjtcbiAgICBtaW51dGVTdGVwOiBudW1iZXI7XG4gICAgc2Vjb25kU3RlcDogbnVtYmVyO1xuICAgIGRpc2FibGVkOiBib29sZWFuO1xuICAgIHJlYWRvbmx5SW5wdXRzOiBib29sZWFuO1xuICAgIHNpemU6ICdzbWFsbCcgfCAnbWVkaXVtJyB8ICdsYXJnZSc7XG59XG4iXX0=