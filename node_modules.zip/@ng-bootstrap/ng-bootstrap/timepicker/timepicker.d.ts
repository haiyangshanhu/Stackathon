import { ChangeDetectorRef, OnChanges, SimpleChanges } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import { NgbTime } from './ngb-time';
import { NgbTimepickerConfig } from './timepicker-config';
import { NgbTimeAdapter } from './ngb-time-adapter';
import { NgbTimepickerI18n } from './timepicker-i18n';
/**
 * A directive that helps with wth picking hours, minutes and seconds.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbTimepicker implements ControlValueAccessor, OnChanges {
    private readonly _config;
    private _ngbTimeAdapter;
    private _cd;
    i18n: NgbTimepickerI18n;
    static ngAcceptInputType_size: string;
    disabled: boolean;
    model: NgbTime;
    private _hourStep;
    private _minuteStep;
    private _secondStep;
    /**
     * Whether to display 12H or 24H mode.
     */
    meridian: boolean;
    /**
     * If `true`, the spinners above and below inputs are visible.
     */
    spinners: boolean;
    /**
     * If `true`, it is possible to select seconds.
     */
    seconds: boolean;
    /**
     * The number of hours to add/subtract when clicking hour spinners.
     */
    set hourStep(step: number);
    get hourStep(): number;
    /**
     * The number of minutes to add/subtract when clicking minute spinners.
     */
    set minuteStep(step: number);
    get minuteStep(): number;
    /**
     * The number of seconds to add/subtract when clicking second spinners.
     */
    set secondStep(step: number);
    get secondStep(): number;
    /**
     * If `true`, the timepicker is readonly and can't be changed.
     */
    readonlyInputs: boolean;
    /**
     * The size of inputs and buttons.
     */
    size: 'small' | 'medium' | 'large';
    constructor(_config: NgbTimepickerConfig, _ngbTimeAdapter: NgbTimeAdapter<any>, _cd: ChangeDetectorRef, i18n: NgbTimepickerI18n);
    onChange: (_: any) => void;
    onTouched: () => void;
    writeValue(value: any): void;
    registerOnChange(fn: (value: any) => any): void;
    registerOnTouched(fn: () => any): void;
    setDisabledState(isDisabled: boolean): void;
    changeHour(step: number): void;
    changeMinute(step: number): void;
    changeSecond(step: number): void;
    updateHour(newVal: string): void;
    updateMinute(newVal: string): void;
    updateSecond(newVal: string): void;
    toggleMeridian(): void;
    formatInput(input: HTMLInputElement): void;
    formatHour(value?: number): string;
    formatMinSec(value?: number): string;
    get isSmallSize(): boolean;
    get isLargeSize(): boolean;
    ngOnChanges(changes: SimpleChanges): void;
    private propagateModelChange;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbTimepicker, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbTimepicker, "ngb-timepicker", never, { "meridian": "meridian"; "spinners": "spinners"; "seconds": "seconds"; "hourStep": "hourStep"; "minuteStep": "minuteStep"; "secondStep": "secondStep"; "readonlyInputs": "readonlyInputs"; "size": "size"; }, {}, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXBpY2tlci5kLnRzIiwic291cmNlcyI6WyJ0aW1lcGlja2VyLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENoYW5nZURldGVjdG9yUmVmLCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbnRyb2xWYWx1ZUFjY2Vzc29yIH0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHsgTmdiVGltZSB9IGZyb20gJy4vbmdiLXRpbWUnO1xuaW1wb3J0IHsgTmdiVGltZXBpY2tlckNvbmZpZyB9IGZyb20gJy4vdGltZXBpY2tlci1jb25maWcnO1xuaW1wb3J0IHsgTmdiVGltZUFkYXB0ZXIgfSBmcm9tICcuL25nYi10aW1lLWFkYXB0ZXInO1xuaW1wb3J0IHsgTmdiVGltZXBpY2tlckkxOG4gfSBmcm9tICcuL3RpbWVwaWNrZXItaTE4bic7XG4vKipcbiAqIEEgZGlyZWN0aXZlIHRoYXQgaGVscHMgd2l0aCB3dGggcGlja2luZyBob3VycywgbWludXRlcyBhbmQgc2Vjb25kcy5cbiAqL1xuZXhwb3J0IGRlY2xhcmUgY2xhc3MgTmdiVGltZXBpY2tlciBpbXBsZW1lbnRzIENvbnRyb2xWYWx1ZUFjY2Vzc29yLCBPbkNoYW5nZXMge1xuICAgIHByaXZhdGUgcmVhZG9ubHkgX2NvbmZpZztcbiAgICBwcml2YXRlIF9uZ2JUaW1lQWRhcHRlcjtcbiAgICBwcml2YXRlIF9jZDtcbiAgICBpMThuOiBOZ2JUaW1lcGlja2VySTE4bjtcbiAgICBzdGF0aWMgbmdBY2NlcHRJbnB1dFR5cGVfc2l6ZTogc3RyaW5nO1xuICAgIGRpc2FibGVkOiBib29sZWFuO1xuICAgIG1vZGVsOiBOZ2JUaW1lO1xuICAgIHByaXZhdGUgX2hvdXJTdGVwO1xuICAgIHByaXZhdGUgX21pbnV0ZVN0ZXA7XG4gICAgcHJpdmF0ZSBfc2Vjb25kU3RlcDtcbiAgICAvKipcbiAgICAgKiBXaGV0aGVyIHRvIGRpc3BsYXkgMTJIIG9yIDI0SCBtb2RlLlxuICAgICAqL1xuICAgIG1lcmlkaWFuOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIElmIGB0cnVlYCwgdGhlIHNwaW5uZXJzIGFib3ZlIGFuZCBiZWxvdyBpbnB1dHMgYXJlIHZpc2libGUuXG4gICAgICovXG4gICAgc3Bpbm5lcnM6IGJvb2xlYW47XG4gICAgLyoqXG4gICAgICogSWYgYHRydWVgLCBpdCBpcyBwb3NzaWJsZSB0byBzZWxlY3Qgc2Vjb25kcy5cbiAgICAgKi9cbiAgICBzZWNvbmRzOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIFRoZSBudW1iZXIgb2YgaG91cnMgdG8gYWRkL3N1YnRyYWN0IHdoZW4gY2xpY2tpbmcgaG91ciBzcGlubmVycy5cbiAgICAgKi9cbiAgICBzZXQgaG91clN0ZXAoc3RlcDogbnVtYmVyKTtcbiAgICBnZXQgaG91clN0ZXAoKTogbnVtYmVyO1xuICAgIC8qKlxuICAgICAqIFRoZSBudW1iZXIgb2YgbWludXRlcyB0byBhZGQvc3VidHJhY3Qgd2hlbiBjbGlja2luZyBtaW51dGUgc3Bpbm5lcnMuXG4gICAgICovXG4gICAgc2V0IG1pbnV0ZVN0ZXAoc3RlcDogbnVtYmVyKTtcbiAgICBnZXQgbWludXRlU3RlcCgpOiBudW1iZXI7XG4gICAgLyoqXG4gICAgICogVGhlIG51bWJlciBvZiBzZWNvbmRzIHRvIGFkZC9zdWJ0cmFjdCB3aGVuIGNsaWNraW5nIHNlY29uZCBzcGlubmVycy5cbiAgICAgKi9cbiAgICBzZXQgc2Vjb25kU3RlcChzdGVwOiBudW1iZXIpO1xuICAgIGdldCBzZWNvbmRTdGVwKCk6IG51bWJlcjtcbiAgICAvKipcbiAgICAgKiBJZiBgdHJ1ZWAsIHRoZSB0aW1lcGlja2VyIGlzIHJlYWRvbmx5IGFuZCBjYW4ndCBiZSBjaGFuZ2VkLlxuICAgICAqL1xuICAgIHJlYWRvbmx5SW5wdXRzOiBib29sZWFuO1xuICAgIC8qKlxuICAgICAqIFRoZSBzaXplIG9mIGlucHV0cyBhbmQgYnV0dG9ucy5cbiAgICAgKi9cbiAgICBzaXplOiAnc21hbGwnIHwgJ21lZGl1bScgfCAnbGFyZ2UnO1xuICAgIGNvbnN0cnVjdG9yKF9jb25maWc6IE5nYlRpbWVwaWNrZXJDb25maWcsIF9uZ2JUaW1lQWRhcHRlcjogTmdiVGltZUFkYXB0ZXI8YW55PiwgX2NkOiBDaGFuZ2VEZXRlY3RvclJlZiwgaTE4bjogTmdiVGltZXBpY2tlckkxOG4pO1xuICAgIG9uQ2hhbmdlOiAoXzogYW55KSA9PiB2b2lkO1xuICAgIG9uVG91Y2hlZDogKCkgPT4gdm9pZDtcbiAgICB3cml0ZVZhbHVlKHZhbHVlOiBhbnkpOiB2b2lkO1xuICAgIHJlZ2lzdGVyT25DaGFuZ2UoZm46ICh2YWx1ZTogYW55KSA9PiBhbnkpOiB2b2lkO1xuICAgIHJlZ2lzdGVyT25Ub3VjaGVkKGZuOiAoKSA9PiBhbnkpOiB2b2lkO1xuICAgIHNldERpc2FibGVkU3RhdGUoaXNEaXNhYmxlZDogYm9vbGVhbik6IHZvaWQ7XG4gICAgY2hhbmdlSG91cihzdGVwOiBudW1iZXIpOiB2b2lkO1xuICAgIGNoYW5nZU1pbnV0ZShzdGVwOiBudW1iZXIpOiB2b2lkO1xuICAgIGNoYW5nZVNlY29uZChzdGVwOiBudW1iZXIpOiB2b2lkO1xuICAgIHVwZGF0ZUhvdXIobmV3VmFsOiBzdHJpbmcpOiB2b2lkO1xuICAgIHVwZGF0ZU1pbnV0ZShuZXdWYWw6IHN0cmluZyk6IHZvaWQ7XG4gICAgdXBkYXRlU2Vjb25kKG5ld1ZhbDogc3RyaW5nKTogdm9pZDtcbiAgICB0b2dnbGVNZXJpZGlhbigpOiB2b2lkO1xuICAgIGZvcm1hdElucHV0KGlucHV0OiBIVE1MSW5wdXRFbGVtZW50KTogdm9pZDtcbiAgICBmb3JtYXRIb3VyKHZhbHVlPzogbnVtYmVyKTogc3RyaW5nO1xuICAgIGZvcm1hdE1pblNlYyh2YWx1ZT86IG51bWJlcik6IHN0cmluZztcbiAgICBnZXQgaXNTbWFsbFNpemUoKTogYm9vbGVhbjtcbiAgICBnZXQgaXNMYXJnZVNpemUoKTogYm9vbGVhbjtcbiAgICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZDtcbiAgICBwcml2YXRlIHByb3BhZ2F0ZU1vZGVsQ2hhbmdlO1xufVxuIl19