import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './timepicker';
import * as ɵngcc2 from '@angular/common';
export { NgbTimepicker } from './timepicker';
export { NgbTimepickerConfig } from './timepicker-config';
export { NgbTimeStruct } from './ngb-time-struct';
export { NgbTimeAdapter } from './ngb-time-adapter';
export { NgbTimepickerI18n } from './timepicker-i18n';
export declare class NgbTimepickerModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbTimepickerModule, [typeof ɵngcc1.NgbTimepicker], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbTimepicker]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbTimepickerModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZXBpY2tlci5tb2R1bGUuZC50cyIsInNvdXJjZXMiOlsidGltZXBpY2tlci5tb2R1bGUuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IHsgTmdiVGltZXBpY2tlciB9IGZyb20gJy4vdGltZXBpY2tlcic7XG5leHBvcnQgeyBOZ2JUaW1lcGlja2VyQ29uZmlnIH0gZnJvbSAnLi90aW1lcGlja2VyLWNvbmZpZyc7XG5leHBvcnQgeyBOZ2JUaW1lU3RydWN0IH0gZnJvbSAnLi9uZ2ItdGltZS1zdHJ1Y3QnO1xuZXhwb3J0IHsgTmdiVGltZUFkYXB0ZXIgfSBmcm9tICcuL25nYi10aW1lLWFkYXB0ZXInO1xuZXhwb3J0IHsgTmdiVGltZXBpY2tlckkxOG4gfSBmcm9tICcuL3RpbWVwaWNrZXItaTE4bic7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JUaW1lcGlja2VyTW9kdWxlIHtcbn1cbiJdfQ==