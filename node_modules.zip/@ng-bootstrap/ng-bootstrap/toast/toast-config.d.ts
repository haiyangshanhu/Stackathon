/**
 * Interface used to type all toast config options. See `NgbToastConfig`.
 *
 * @since 5.0.0
 */
import * as ɵngcc0 from '@angular/core';
export interface NgbToastOptions {
    /**
     * Specify if the toast component should emit the `hide()` output
     * after a certain `delay` in ms.
     */
    autohide?: boolean;
    /**
     * Delay in ms after which the `hide()` output should be emitted.
     */
    delay?: number;
    /**
     * Type of aria-live attribute to be used.
     *
     * Could be one of these 2 values (as string):
     * - `polite` (default)
     * - `alert`
     */
    ariaLive?: 'polite' | 'alert';
}
/**
 * Configuration service for the NgbToast component. You can inject this service, typically in your root component,
 * and customize the values of its properties in order to provide default values for all the toasts used in the
 * application.
 *
 * @since 5.0.0
 */
export declare class NgbToastConfig implements NgbToastOptions {
    autohide: boolean;
    delay: number;
    ariaLive: 'polite' | 'alert';
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbToastConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3QtY29uZmlnLmQudHMiLCJzb3VyY2VzIjpbInRvYXN0LWNvbmZpZy5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBJbnRlcmZhY2UgdXNlZCB0byB0eXBlIGFsbCB0b2FzdCBjb25maWcgb3B0aW9ucy4gU2VlIGBOZ2JUb2FzdENvbmZpZ2AuXG4gKlxuICogQHNpbmNlIDUuMC4wXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgTmdiVG9hc3RPcHRpb25zIHtcbiAgICAvKipcbiAgICAgKiBTcGVjaWZ5IGlmIHRoZSB0b2FzdCBjb21wb25lbnQgc2hvdWxkIGVtaXQgdGhlIGBoaWRlKClgIG91dHB1dFxuICAgICAqIGFmdGVyIGEgY2VydGFpbiBgZGVsYXlgIGluIG1zLlxuICAgICAqL1xuICAgIGF1dG9oaWRlPzogYm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBEZWxheSBpbiBtcyBhZnRlciB3aGljaCB0aGUgYGhpZGUoKWAgb3V0cHV0IHNob3VsZCBiZSBlbWl0dGVkLlxuICAgICAqL1xuICAgIGRlbGF5PzogbnVtYmVyO1xuICAgIC8qKlxuICAgICAqIFR5cGUgb2YgYXJpYS1saXZlIGF0dHJpYnV0ZSB0byBiZSB1c2VkLlxuICAgICAqXG4gICAgICogQ291bGQgYmUgb25lIG9mIHRoZXNlIDIgdmFsdWVzIChhcyBzdHJpbmcpOlxuICAgICAqIC0gYHBvbGl0ZWAgKGRlZmF1bHQpXG4gICAgICogLSBgYWxlcnRgXG4gICAgICovXG4gICAgYXJpYUxpdmU/OiAncG9saXRlJyB8ICdhbGVydCc7XG59XG4vKipcbiAqIENvbmZpZ3VyYXRpb24gc2VydmljZSBmb3IgdGhlIE5nYlRvYXN0IGNvbXBvbmVudC4gWW91IGNhbiBpbmplY3QgdGhpcyBzZXJ2aWNlLCB0eXBpY2FsbHkgaW4geW91ciByb290IGNvbXBvbmVudCxcbiAqIGFuZCBjdXN0b21pemUgdGhlIHZhbHVlcyBvZiBpdHMgcHJvcGVydGllcyBpbiBvcmRlciB0byBwcm92aWRlIGRlZmF1bHQgdmFsdWVzIGZvciBhbGwgdGhlIHRvYXN0cyB1c2VkIGluIHRoZVxuICogYXBwbGljYXRpb24uXG4gKlxuICogQHNpbmNlIDUuMC4wXG4gKi9cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlRvYXN0Q29uZmlnIGltcGxlbWVudHMgTmdiVG9hc3RPcHRpb25zIHtcbiAgICBhdXRvaGlkZTogYm9vbGVhbjtcbiAgICBkZWxheTogbnVtYmVyO1xuICAgIGFyaWFMaXZlOiAncG9saXRlJyB8ICdhbGVydCc7XG59XG4iXX0=