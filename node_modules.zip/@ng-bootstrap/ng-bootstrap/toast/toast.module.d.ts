import * as ɵngcc0 from '@angular/core';
import * as ɵngcc1 from './toast';
import * as ɵngcc2 from '@angular/common';
export { NgbToast, NgbToastHeader } from './toast';
export { NgbToastConfig, NgbToastOptions } from './toast-config';
export declare class NgbToastModule {
    static ɵmod: ɵngcc0.ɵɵNgModuleDefWithMeta<NgbToastModule, [typeof ɵngcc1.NgbToast, typeof ɵngcc1.NgbToastHeader], [typeof ɵngcc2.CommonModule], [typeof ɵngcc1.NgbToast, typeof ɵngcc1.NgbToastHeader]>;
    static ɵinj: ɵngcc0.ɵɵInjectorDef<NgbToastModule>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9hc3QubW9kdWxlLmQudHMiLCJzb3VyY2VzIjpbInRvYXN0Lm1vZHVsZS5kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgeyBOZ2JUb2FzdCwgTmdiVG9hc3RIZWFkZXIgfSBmcm9tICcuL3RvYXN0JztcbmV4cG9ydCB7IE5nYlRvYXN0Q29uZmlnLCBOZ2JUb2FzdE9wdGlvbnMgfSBmcm9tICcuL3RvYXN0LWNvbmZpZyc7XG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JUb2FzdE1vZHVsZSB7XG59XG4iXX0=