import { PlacementArray } from '../util/positioning';
/**
 * A configuration service for the [`NgbTooltip`](#/components/tooltip/api#NgbTooltip) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the tooltips used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbTooltipConfig {
    autoClose: boolean | 'inside' | 'outside';
    placement: PlacementArray;
    triggers: string;
    container: string;
    disableTooltip: boolean;
    tooltipClass: string;
    openDelay: number;
    closeDelay: number;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbTooltipConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidG9vbHRpcC1jb25maWcuZC50cyIsInNvdXJjZXMiOlsidG9vbHRpcC1jb25maWcuZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQbGFjZW1lbnRBcnJheSB9IGZyb20gJy4uL3V0aWwvcG9zaXRpb25pbmcnO1xuLyoqXG4gKiBBIGNvbmZpZ3VyYXRpb24gc2VydmljZSBmb3IgdGhlIFtgTmdiVG9vbHRpcGBdKCMvY29tcG9uZW50cy90b29sdGlwL2FwaSNOZ2JUb29sdGlwKSBjb21wb25lbnQuXG4gKlxuICogWW91IGNhbiBpbmplY3QgdGhpcyBzZXJ2aWNlLCB0eXBpY2FsbHkgaW4geW91ciByb290IGNvbXBvbmVudCwgYW5kIGN1c3RvbWl6ZSB0aGUgdmFsdWVzIG9mIGl0cyBwcm9wZXJ0aWVzIGluXG4gKiBvcmRlciB0byBwcm92aWRlIGRlZmF1bHQgdmFsdWVzIGZvciBhbGwgdGhlIHRvb2x0aXBzIHVzZWQgaW4gdGhlIGFwcGxpY2F0aW9uLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JUb29sdGlwQ29uZmlnIHtcbiAgICBhdXRvQ2xvc2U6IGJvb2xlYW4gfCAnaW5zaWRlJyB8ICdvdXRzaWRlJztcbiAgICBwbGFjZW1lbnQ6IFBsYWNlbWVudEFycmF5O1xuICAgIHRyaWdnZXJzOiBzdHJpbmc7XG4gICAgY29udGFpbmVyOiBzdHJpbmc7XG4gICAgZGlzYWJsZVRvb2x0aXA6IGJvb2xlYW47XG4gICAgdG9vbHRpcENsYXNzOiBzdHJpbmc7XG4gICAgb3BlbkRlbGF5OiBudW1iZXI7XG4gICAgY2xvc2VEZWxheTogbnVtYmVyO1xufVxuIl19