import { PlacementArray } from '../util/positioning';
/**
 * A configuration service for the [`NgbTypeahead`](#/components/typeahead/api#NgbTypeahead) component.
 *
 * You can inject this service, typically in your root component, and customize the values of its properties in
 * order to provide default values for all the typeaheads used in the application.
 */
import * as ɵngcc0 from '@angular/core';
export declare class NgbTypeaheadConfig {
    container: any;
    editable: boolean;
    focusFirst: boolean;
    showHint: boolean;
    placement: PlacementArray;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbTypeaheadConfig, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHlwZWFoZWFkLWNvbmZpZy5kLnRzIiwic291cmNlcyI6WyJ0eXBlYWhlYWQtY29uZmlnLmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUGxhY2VtZW50QXJyYXkgfSBmcm9tICcuLi91dGlsL3Bvc2l0aW9uaW5nJztcbi8qKlxuICogQSBjb25maWd1cmF0aW9uIHNlcnZpY2UgZm9yIHRoZSBbYE5nYlR5cGVhaGVhZGBdKCMvY29tcG9uZW50cy90eXBlYWhlYWQvYXBpI05nYlR5cGVhaGVhZCkgY29tcG9uZW50LlxuICpcbiAqIFlvdSBjYW4gaW5qZWN0IHRoaXMgc2VydmljZSwgdHlwaWNhbGx5IGluIHlvdXIgcm9vdCBjb21wb25lbnQsIGFuZCBjdXN0b21pemUgdGhlIHZhbHVlcyBvZiBpdHMgcHJvcGVydGllcyBpblxuICogb3JkZXIgdG8gcHJvdmlkZSBkZWZhdWx0IHZhbHVlcyBmb3IgYWxsIHRoZSB0eXBlYWhlYWRzIHVzZWQgaW4gdGhlIGFwcGxpY2F0aW9uLlxuICovXG5leHBvcnQgZGVjbGFyZSBjbGFzcyBOZ2JUeXBlYWhlYWRDb25maWcge1xuICAgIGNvbnRhaW5lcjogYW55O1xuICAgIGVkaXRhYmxlOiBib29sZWFuO1xuICAgIGZvY3VzRmlyc3Q6IGJvb2xlYW47XG4gICAgc2hvd0hpbnQ6IGJvb2xlYW47XG4gICAgcGxhY2VtZW50OiBQbGFjZW1lbnRBcnJheTtcbn1cbiJdfQ==