import { EventEmitter, OnInit, TemplateRef } from '@angular/core';
import { toString } from '../util/util';
/**
 * The context for the typeahead result template in case you want to override the default one.
 */
import * as ɵngcc0 from '@angular/core';
export interface ResultTemplateContext {
    /**
     * Your typeahead result item.
     */
    result: any;
    /**
     * Search term from the `<input>` used to get current result.
     */
    term: string;
}
export declare class NgbTypeaheadWindow implements OnInit {
    activeIdx: number;
    /**
     *  The id for the typeahead window. The id should be unique and the same
     *  as the associated typeahead's id.
     */
    id: string;
    /**
     * Flag indicating if the first row should be active initially
     */
    focusFirst: boolean;
    /**
     * Typeahead match results to be displayed
     */
    results: any;
    /**
     * Search term used to get current results
     */
    term: string;
    /**
     * A function used to format a given result before display. This function should return a formatted string without any
     * HTML markup
     */
    formatter: typeof toString;
    /**
     * A template to override a matching result default display
     */
    resultTemplate: TemplateRef<ResultTemplateContext>;
    /**
     * Event raised when user selects a particular result row
     */
    selectEvent: EventEmitter<any>;
    activeChangeEvent: EventEmitter<any>;
    hasActive(): boolean;
    getActive(): any;
    markActive(activeIdx: number): void;
    next(): void;
    prev(): void;
    resetActive(): void;
    select(item: any): void;
    ngOnInit(): void;
    private _activeChanged;
    static ɵfac: ɵngcc0.ɵɵFactoryDef<NgbTypeaheadWindow, never>;
    static ɵcmp: ɵngcc0.ɵɵComponentDefWithMeta<NgbTypeaheadWindow, "ngb-typeahead-window", ["ngbTypeaheadWindow"], { "focusFirst": "focusFirst"; "formatter": "formatter"; "id": "id"; "results": "results"; "term": "term"; "resultTemplate": "resultTemplate"; }, { "selectEvent": "select"; "activeChangeEvent": "activeChange"; }, never, never>;
}

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHlwZWFoZWFkLXdpbmRvdy5kLnRzIiwic291cmNlcyI6WyJ0eXBlYWhlYWQtd2luZG93LmQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7O0FBQ0EiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFdmVudEVtaXR0ZXIsIE9uSW5pdCwgVGVtcGxhdGVSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IHRvU3RyaW5nIH0gZnJvbSAnLi4vdXRpbC91dGlsJztcbi8qKlxuICogVGhlIGNvbnRleHQgZm9yIHRoZSB0eXBlYWhlYWQgcmVzdWx0IHRlbXBsYXRlIGluIGNhc2UgeW91IHdhbnQgdG8gb3ZlcnJpZGUgdGhlIGRlZmF1bHQgb25lLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJlc3VsdFRlbXBsYXRlQ29udGV4dCB7XG4gICAgLyoqXG4gICAgICogWW91ciB0eXBlYWhlYWQgcmVzdWx0IGl0ZW0uXG4gICAgICovXG4gICAgcmVzdWx0OiBhbnk7XG4gICAgLyoqXG4gICAgICogU2VhcmNoIHRlcm0gZnJvbSB0aGUgYDxpbnB1dD5gIHVzZWQgdG8gZ2V0IGN1cnJlbnQgcmVzdWx0LlxuICAgICAqL1xuICAgIHRlcm06IHN0cmluZztcbn1cbmV4cG9ydCBkZWNsYXJlIGNsYXNzIE5nYlR5cGVhaGVhZFdpbmRvdyBpbXBsZW1lbnRzIE9uSW5pdCB7XG4gICAgYWN0aXZlSWR4OiBudW1iZXI7XG4gICAgLyoqXG4gICAgICogIFRoZSBpZCBmb3IgdGhlIHR5cGVhaGVhZCB3aW5kb3cuIFRoZSBpZCBzaG91bGQgYmUgdW5pcXVlIGFuZCB0aGUgc2FtZVxuICAgICAqICBhcyB0aGUgYXNzb2NpYXRlZCB0eXBlYWhlYWQncyBpZC5cbiAgICAgKi9cbiAgICBpZDogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIEZsYWcgaW5kaWNhdGluZyBpZiB0aGUgZmlyc3Qgcm93IHNob3VsZCBiZSBhY3RpdmUgaW5pdGlhbGx5XG4gICAgICovXG4gICAgZm9jdXNGaXJzdDogYm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBUeXBlYWhlYWQgbWF0Y2ggcmVzdWx0cyB0byBiZSBkaXNwbGF5ZWRcbiAgICAgKi9cbiAgICByZXN1bHRzOiBhbnk7XG4gICAgLyoqXG4gICAgICogU2VhcmNoIHRlcm0gdXNlZCB0byBnZXQgY3VycmVudCByZXN1bHRzXG4gICAgICovXG4gICAgdGVybTogc3RyaW5nO1xuICAgIC8qKlxuICAgICAqIEEgZnVuY3Rpb24gdXNlZCB0byBmb3JtYXQgYSBnaXZlbiByZXN1bHQgYmVmb3JlIGRpc3BsYXkuIFRoaXMgZnVuY3Rpb24gc2hvdWxkIHJldHVybiBhIGZvcm1hdHRlZCBzdHJpbmcgd2l0aG91dCBhbnlcbiAgICAgKiBIVE1MIG1hcmt1cFxuICAgICAqL1xuICAgIGZvcm1hdHRlcjogdHlwZW9mIHRvU3RyaW5nO1xuICAgIC8qKlxuICAgICAqIEEgdGVtcGxhdGUgdG8gb3ZlcnJpZGUgYSBtYXRjaGluZyByZXN1bHQgZGVmYXVsdCBkaXNwbGF5XG4gICAgICovXG4gICAgcmVzdWx0VGVtcGxhdGU6IFRlbXBsYXRlUmVmPFJlc3VsdFRlbXBsYXRlQ29udGV4dD47XG4gICAgLyoqXG4gICAgICogRXZlbnQgcmFpc2VkIHdoZW4gdXNlciBzZWxlY3RzIGEgcGFydGljdWxhciByZXN1bHQgcm93XG4gICAgICovXG4gICAgc2VsZWN0RXZlbnQ6IEV2ZW50RW1pdHRlcjxhbnk+O1xuICAgIGFjdGl2ZUNoYW5nZUV2ZW50OiBFdmVudEVtaXR0ZXI8YW55PjtcbiAgICBoYXNBY3RpdmUoKTogYm9vbGVhbjtcbiAgICBnZXRBY3RpdmUoKTogYW55O1xuICAgIG1hcmtBY3RpdmUoYWN0aXZlSWR4OiBudW1iZXIpOiB2b2lkO1xuICAgIG5leHQoKTogdm9pZDtcbiAgICBwcmV2KCk6IHZvaWQ7XG4gICAgcmVzZXRBY3RpdmUoKTogdm9pZDtcbiAgICBzZWxlY3QoaXRlbTogYW55KTogdm9pZDtcbiAgICBuZ09uSW5pdCgpOiB2b2lkO1xuICAgIHByaXZhdGUgX2FjdGl2ZUNoYW5nZWQ7XG59XG4iXX0=