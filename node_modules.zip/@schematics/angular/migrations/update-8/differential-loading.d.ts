import { Rule } from '@angular-devkit/schematics';
export declare function updateES5Projects(): Rule;
