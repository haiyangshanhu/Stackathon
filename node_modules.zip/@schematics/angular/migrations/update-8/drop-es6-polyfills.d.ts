import { Rule } from '@angular-devkit/schematics';
/**
 * Drop ES2015 polyfills from all application projects
 */
export declare function dropES2015Polyfills(): Rule;
