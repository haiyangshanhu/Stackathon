export declare function updateDependencies(): (host: import("../../../../angular_devkit/schematics/src/tree/interface").Tree) => void;
