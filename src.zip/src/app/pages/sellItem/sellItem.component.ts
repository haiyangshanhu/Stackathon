import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sellItem',
  templateUrl: './sellItem.component.html',
  styleUrls: ['./sellItem.component.css']
})
export class SellItemComponent implements OnInit {

  constructor() { }

  public soldFlg:boolean = false;
  public sellItem:any = [{
    id: '3',
    price: 7999,
    title: 'Iphone7 Y7000P',
    desc: 'iPhone 7 dramatically improves the most important aspects of the iPhone experience.',
    pic: 'assets/iphone.jpg',
    sum: 1,
    updateDate: '2010/05/09',
    soldFlg: '1',
    buyer: 'buyer_1',
    transactionNo: 't00001' 
  
  },{
    id: '4',
    price: 7999,
    title: 'ipad Air',
    desc: 'The ipad Air A slim and lightweight body that can run on a battery for a long time. 14.0 type WQHD display, LTE can be selected. It also has robust security and offers high performance.',
    pic: 'assets/ipad.jpg',
    sum: 1,
    updateDate: '2010/05/09',
    soldFlg: '1',
    buyer: 'buyer_2',
    transactionNo: 't00002' 
  
  }]
  ngOnInit() {
      this.soldFlg=true;
    
  }

}
