if (process.env.CI || process.env.ADBLOCK || process.env.DISABLE_OPENCOLLECTIVE) return;

console.log(
`###########################################################
# contribute to Terser! https://opencollective.com/terser #
###########################################################
`)
