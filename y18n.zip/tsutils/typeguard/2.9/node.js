"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
tslib_1.__exportStar(require("../2.8/node"), exports);
var ts = require("typescript");
function isImportTypeNode(node) {
    return node.kind === ts.SyntaxKind.ImportType;
}
exports.isImportTypeNode = isImportTypeNode;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibm9kZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIm5vZGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsc0RBQTRCO0FBRTVCLCtCQUFpQztBQUVqQyxTQUFnQixnQkFBZ0IsQ0FBQyxJQUFhO0lBQzFDLE9BQU8sSUFBSSxDQUFDLElBQUksS0FBSyxFQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQztBQUNsRCxDQUFDO0FBRkQsNENBRUMifQ==